import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  FileText,
  Fingerprint,
  Flag,
  Menu,
  Minus,
  MoveUpRight,
  PenLine,
  ScanSearch,
  Shield,
  Sparkles,
  X,
} from "lucide-react";

type Risk = {
  id: string;
  number: string;
  title: string;
  short: string;
  clause: string;
  why: string;
  ask: string;
  tone: "critical" | "watch" | "fair";
};

const risks: Risk[] = [
  {
    id: "renewal",
    number: "01",
    title: "Auto-renewal",
    short: "The quiet extension",
    clause:
      "This Agreement will automatically renew for successive twelve (12) month periods unless either party provides written notice of non-renewal at least 60 days prior to the end of the then-current term.",
    why: "Miss the window and you are committed for another year, even if the work has changed or the client has gone quiet.",
    ask: "Change the notice period to 14 days, or remove automatic renewal entirely.",
    tone: "watch",
  },
  {
    id: "liability",
    number: "02",
    title: "Unlimited liability",
    short: "The blank cheque",
    clause:
      "Contractor shall be liable for any and all losses, costs, claims, damages, and expenses arising out of or related to the Services, without limitation.",
    why: "A $2,000 project should not expose your personal finances to an open-ended claim. One typo should not become an unlimited bill.",
    ask: "Cap your total liability at the fees paid under this agreement.",
    tone: "critical",
  },
  {
    id: "ip",
    number: "03",
    title: "IP assignment",
    short: "Giving away the toolbox",
    clause:
      "All right, title, and interest in any materials, tools, processes, concepts, and deliverables created by Contractor shall vest exclusively in Client upon creation.",
    why: "As written, the client could claim ownership of your reusable templates, methods, and work-in-progress — not just the final deliverable.",
    ask: "Carve out pre-existing materials, tools, and general know-how from the assignment.",
    tone: "critical",
  },
  {
    id: "noncompete",
    number: "04",
    title: "Non-compete",
    short: "The door closing behind you",
    clause:
      "During the term and for twelve (12) months thereafter, Contractor shall not provide services to any business that competes with Client.",
    why: "A broad restriction can quietly shrink your client list and stop you taking work in your own industry.",
    ask: "Limit the restriction to named, direct competitors — or delete it.",
    tone: "watch",
  },
  {
    id: "termination",
    number: "05",
    title: "Unilateral termination",
    short: "The one-way exit",
    clause:
      "Client may terminate this Agreement at any time, for any reason, upon written notice. Contractor shall be paid only for accepted work completed through the effective date.",
    why: "They can leave whenever they want, while your payment depends on a vague idea of what counts as accepted.",
    ask: "Add 14 days' notice and payment for work completed plus committed costs.",
    tone: "watch",
  },
];

const faqs = [
  {
    question: "Is Redline legal advice?",
    answer:
      "No. Redline is a plain-language contract safety tool, not a lawyer and not a substitute for legal advice. It helps you spot questions worth asking and gives you practical language for a conversation with a client or counsel.",
  },
  {
    question: "Will it rewrite my whole contract?",
    answer:
      "Redline focuses on the clauses most likely to create an expensive surprise: liability, ownership, renewal, restrictions, and exit terms. You get a focused read, not a fog of tracked changes.",
  },
  {
    question: "What happens to the contracts I upload?",
    answer:
      "Your documents are private to your account and used to generate your report. We do not sell your contracts or use them to train a public model. You can delete a document and its analysis whenever you like.",
  },
  {
    question: "What kind of freelancer is this for?",
    answer:
      "Anyone signing client work without a legal department behind them: designers, developers, strategists, photographers, writers, producers, and consultants. If your name is on the agreement, Redline is for you.",
  },
];

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.12 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return { ref, visible };
}

function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={`${className} redline-reveal ${visible ? "is-visible" : ""}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <div className={`flex items-center gap-2.5 ${dark ? "text-[#f5eee4]" : "text-[#1c2020]"}`}>
      <span className="relative flex h-8 w-8 items-center justify-center border-2 border-current">
        <span className="absolute h-3.5 w-3.5 bg-[#ef493b]" />
        <span className="absolute right-[-4px] top-[-4px] h-2 w-2 bg-[#1c2020]" />
      </span>
      <span className="font-mono text-[13px] font-bold uppercase tracking-[0.18em]">
        redline<span className="text-[#ef493b]">.</span>
      </span>
    </div>
  );
}

function HighlightedClause() {
  return (
    <p className="font-serif text-[17px] leading-[1.85] text-[#343a38]">
      Contractor shall be liable for{" "}
      <span className="redline-highlight">any and all losses</span>, costs, claims, damages,
      and expenses arising out of or related to the Services,{" "}
      <span className="redline-highlight redline-highlight-strong">without limitation</span>.
    </p>
  );
}

export function RedlineLanding() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeRisk, setActiveRisk] = useState("liability");
  const [openFaq, setOpenFaq] = useState(0);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const selectedRisk = risks.find((risk) => risk.id === activeRisk) ?? risks[1];

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const submitEmail = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (email.trim()) setSubmitted(true);
  };

  return (
    <main className="redline-page min-h-[100dvh] overflow-hidden bg-[#f5eee4] text-[#1c2020]">
      <style>{`
        .redline-page {
          --ink: #1c2020;
          --paper: #f5eee4;
          --paper-deep: #e9dfd1;
          --red: #ef493b;
          --red-dark: #c9382f;
          --sage: #b8c7b6;
          --line: rgba(28,32,32,.18);
          font-family: "DM Sans", "Avenir Next", sans-serif;
          background-image: radial-gradient(rgba(28,32,32,.055) .65px, transparent .65px);
          background-size: 6px 6px;
        }
        .redline-page * { box-sizing: border-box; }
        .redline-serif { font-family: "Instrument Serif", Georgia, serif; }
        .redline-mono { font-family: "Space Mono", "SFMono-Regular", monospace; }
        .redline-reveal { opacity: 0; transform: translateY(24px); transition: opacity .75s ease, transform .75s cubic-bezier(.22,1,.36,1); }
        .redline-reveal.is-visible { opacity: 1; transform: translateY(0); }
        .redline-highlight { background: linear-gradient(transparent 58%, rgba(239,73,59,.34) 58%); }
        .redline-highlight-strong { background: linear-gradient(transparent 48%, rgba(239,73,59,.75) 48%); }
        .redline-arrow-link svg { transition: transform .25s ease; }
        .redline-arrow-link:hover svg { transform: translate(4px, -4px); }
        .redline-grid { background-image: linear-gradient(rgba(28,32,32,.09) 1px, transparent 1px), linear-gradient(90deg, rgba(28,32,32,.09) 1px, transparent 1px); background-size: 22px 22px; }
        .redline-document-line { height: 7px; background: #ddd2c4; }
        .redline-document-line.dark { background: #8e8a80; }
        .redline-document-line.red { background: rgba(239,73,59,.68); }
        .redline-card-hover { transition: transform .28s ease, background-color .28s ease, border-color .28s ease; }
        .redline-card-hover:hover { transform: translateY(-5px); border-color: rgba(239,73,59,.6); background-color: #f9f1e7; }
        .redline-page button, .redline-page a { -webkit-tap-highlight-color: transparent; }
        @media (prefers-reduced-motion: reduce) {
          .redline-reveal { opacity: 1; transform: none; transition: none; }
          .redline-arrow-link svg, .redline-card-hover { transition: none; }
        }
      `}</style>

      <div className="border-b border-[#1c2020]/15 bg-[#1c2020] px-5 py-2 text-center text-[10px] font-bold uppercase tracking-[0.18em] text-[#f5eee4] sm:text-[11px]">
        Built for the people who sign the work
        <span className="mx-2 text-[#ef493b]">/</span>
        No legal degree required
      </div>

      <header className="relative z-30 mx-auto flex max-w-[1320px] items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
        <button type="button" onClick={() => scrollTo("top")} aria-label="Back to top">
          <Logo />
        </button>
        <nav className="hidden items-center gap-8 text-[12px] font-bold uppercase tracking-[0.13em] text-[#1c2020]/65 lg:flex">
          <button type="button" onClick={() => scrollTo("how-it-works")} className="transition-colors hover:text-[#ef493b]">How it works</button>
          <button type="button" onClick={() => scrollTo("risk-index")} className="transition-colors hover:text-[#ef493b]">What it catches</button>
          <button type="button" onClick={() => scrollTo("pricing")} className="transition-colors hover:text-[#ef493b]">Pricing</button>
        </nav>
        <div className="hidden items-center gap-5 lg:flex">
          <button type="button" onClick={() => scrollTo("signup")} className="text-[12px] font-bold uppercase tracking-[0.13em] text-[#1c2020]/70 hover:text-[#ef493b]">Sign in</button>
          <button type="button" onClick={() => scrollTo("signup")} className="flex items-center gap-2 bg-[#ef493b] px-4 py-3 text-[11px] font-bold uppercase tracking-[0.13em] text-[#fff8ed] transition-colors hover:bg-[#c9382f]">
            Try Redline <ArrowRight size={14} />
          </button>
        </div>
        <button type="button" onClick={() => setMobileOpen((open) => !open)} className="p-2 lg:hidden" aria-label="Toggle menu">
          {mobileOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
        {mobileOpen && (
          <div className="absolute left-5 right-5 top-[72px] border border-[#1c2020] bg-[#f5eee4] p-5 shadow-[8px_8px_0_#ef493b] lg:hidden">
            <div className="flex flex-col gap-5 text-left text-[12px] font-bold uppercase tracking-[0.13em]">
              <button type="button" onClick={() => scrollTo("how-it-works")}>How it works</button>
              <button type="button" onClick={() => scrollTo("risk-index")}>What it catches</button>
              <button type="button" onClick={() => scrollTo("pricing")}>Pricing</button>
              <button type="button" onClick={() => scrollTo("signup")} className="border-t border-[#1c2020]/20 pt-5 text-left text-[#ef493b]">Start your read <ArrowRight className="ml-1 inline" size={14} /></button>
            </div>
          </div>
        )}
      </header>

      <section id="top" className="mx-auto grid max-w-[1320px] grid-cols-1 gap-14 px-5 pb-20 pt-10 sm:px-8 lg:grid-cols-[.92fr_1.08fr] lg:gap-10 lg:px-12 lg:pb-28 lg:pt-20">
        <div className="flex flex-col justify-center">
          <Reveal>
            <div className="mb-8 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.18em] text-[#ef493b]">
              <span className="h-[1px] w-9 bg-[#ef493b]" />
              Contract clarity for the self-employed
            </div>
          </Reveal>
          <Reveal delay={90}>
            <h1 className="redline-serif max-w-[650px] text-[clamp(4.4rem,9vw,8.4rem)] leading-[.82] tracking-[-.045em] text-[#1c2020]">
              Don&apos;t sign<br />
              <span className="text-[#ef493b]">blind.</span>
            </h1>
          </Reveal>
          <Reveal delay={170}>
            <p className="mt-9 max-w-[480px] text-[18px] leading-[1.45] text-[#1c2020]/70 sm:text-[20px]">
              Redline reads the contract before you do — and points to the parts that could cost you your time, money, or next client.
            </p>
          </Reveal>
          <Reveal delay={240}>
            <div className="mt-9 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <button type="button" onClick={() => scrollTo("signup")} className="group flex items-center gap-3 bg-[#ef493b] px-5 py-4 text-[12px] font-bold uppercase tracking-[0.1em] text-[#fff8ed] transition-all hover:bg-[#c9382f]">
                Read my contract
                <MoveUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
              <button type="button" onClick={() => scrollTo("analysis-preview")} className="redline-arrow-link flex items-center gap-2 border-b border-[#1c2020]/40 pb-1 text-[12px] font-bold uppercase tracking-[0.1em]">
                See a real read <ArrowRight size={15} />
              </button>
            </div>
          </Reveal>
          <Reveal delay={320}>
            <div className="mt-16 flex items-center gap-4 border-t border-[#1c2020]/15 pt-5">
              <div className="flex -space-x-2">
                {["MC", "JR", "AL", "NP"].map((initials, index) => (
                  <span key={initials} className={`flex h-8 w-8 items-center justify-center border-2 border-[#f5eee4] text-[9px] font-bold text-[#1c2020] ${index % 2 === 0 ? "bg-[#b8c7b6]" : "bg-[#e0a18e]"}`}>{initials}</span>
                ))}
              </div>
              <p className="text-[11px] leading-[1.35] text-[#1c2020]/60">
                <span className="font-bold text-[#1c2020]">Made for freelancers.</span><br />
                Used before the awkward follow-up email.
              </p>
            </div>
          </Reveal>
        </div>

        <Reveal delay={120} className="relative flex items-center justify-center lg:justify-end">
          <div className="relative w-full max-w-[610px]">
            <div className="absolute -left-2 top-8 z-10 flex h-20 w-20 -rotate-12 items-center justify-center rounded-full bg-[#ef493b] text-center text-[10px] font-bold uppercase leading-[1.1] tracking-[0.08em] text-[#fff8ed] sm:-left-8 sm:h-24 sm:w-24">
              Read<br />the fine<br />print
            </div>
            <div className="relative rotate-[2.5deg] border border-[#1c2020]/25 bg-[#fbf7f0] p-5 shadow-[14px_16px_0_rgba(28,32,32,.12)] sm:p-8">
              <div className="mb-6 flex items-center justify-between border-b border-[#1c2020]/15 pb-4">
                <div className="flex items-center gap-2">
                  <FileText size={17} className="text-[#ef493b]" />
                  <span className="redline-mono text-[9px] font-bold uppercase tracking-[0.16em]">website-redesign_agreement.pdf</span>
                </div>
                <span className="redline-mono text-[9px] text-[#1c2020]/45">6 pages</span>
              </div>
              <div className="mb-6">
                <div className="redline-document-line dark mb-3 w-[52%]" />
                <div className="redline-document-line mb-2 w-[90%]" />
                <div className="redline-document-line mb-2 w-[82%]" />
                <div className="redline-document-line mb-2 w-[67%]" />
              </div>
              <div className="mb-7 border-l-2 border-[#ef493b] bg-[#f3ded5] px-4 py-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="redline-mono text-[9px] font-bold uppercase tracking-[0.13em] text-[#c9382f]">Redline found this</span>
                  <CircleAlert size={14} className="text-[#c9382f]" />
                </div>
                <p className="font-serif text-[18px] leading-[1.5] text-[#302c2a]">
                  Contractor shall be liable for <span className="bg-[#ef493b]/35">any and all losses</span>, costs, claims, damages, and expenses arising out of or related to the Services, <span className="bg-[#ef493b]/65">without limitation</span>.
                </p>
              </div>
              <div className="space-y-3">
                <div className="redline-document-line w-full" />
                <div className="redline-document-line w-[94%]" />
                <div className="redline-document-line w-[78%]" />
                <div className="redline-document-line w-[87%]" />
                <div className="redline-document-line w-[44%]" />
              </div>
              <div className="mt-7 flex items-end justify-between border-t border-[#1c2020]/15 pt-4">
                <div>
                  <div className="redline-mono mb-1 text-[9px] font-bold uppercase tracking-[0.12em] text-[#ef493b]">01 / 05 risks found</div>
                  <div className="text-[12px] font-bold">This clause has no ceiling.</div>
                </div>
                <div className="h-9 w-9 border border-[#ef493b] p-2 text-[#ef493b]"><ArrowDown size={18} /></div>
              </div>
            </div>
            <div className="absolute -bottom-7 -right-2 z-10 rotate-[-5deg] border border-[#1c2020]/20 bg-[#b8c7b6] px-4 py-3 shadow-[5px_5px_0_rgba(28,32,32,.12)] sm:-right-6">
              <div className="redline-mono text-[9px] font-bold uppercase tracking-[0.1em]">Risk level</div>
              <div className="mt-1 flex items-center gap-2 text-[15px] font-bold"><span className="h-2 w-2 rounded-full bg-[#ef493b]" /> Worth a conversation</div>
            </div>
          </div>
        </Reveal>
      </section>

      <div className="border-y border-[#f5eee4]/20 bg-[#1c2020] text-[#f5eee4]">
        <div className="mx-auto grid max-w-[1320px] grid-cols-2 px-5 sm:px-8 lg:grid-cols-4 lg:px-12">
          {[
            ["$2,000", "average project protected"],
            ["5", "high-stakes risks surfaced"],
            ["3 min", "to your first clear question"],
            ["$0", "lawyer-shaped price tag"],
          ].map(([stat, label], index) => (
            <div key={stat} className={`border-[#f5eee4]/15 px-3 py-6 sm:px-6 lg:py-8 ${index < 3 ? "border-r" : ""} ${index > 1 ? "border-t lg:border-t-0" : ""}`}>
              <div className="redline-serif text-[32px] leading-none text-[#ef493b] sm:text-[40px]">{stat}</div>
              <div className="mt-2 max-w-[130px] text-[10px] font-bold uppercase leading-[1.3] tracking-[0.12em] text-[#f5eee4]/55">{label}</div>
            </div>
          ))}
        </div>
      </div>

      <section id="how-it-works" className="mx-auto max-w-[1320px] px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
        <Reveal>
          <div className="grid grid-cols-1 gap-8 border-b border-[#1c2020]/20 pb-12 lg:grid-cols-[.65fr_1.35fr] lg:gap-20">
            <div>
              <div className="redline-mono mb-4 text-[10px] font-bold uppercase tracking-[0.15em] text-[#ef493b]">01 — The approach</div>
              <h2 className="redline-serif max-w-[440px] text-[clamp(3.2rem,6vw,5.8rem)] leading-[.88] tracking-[-.04em]">A second set of eyes. <span className="text-[#ef493b]">A sharper voice.</span></h2>
            </div>
            <div className="flex items-end">
              <p className="max-w-[590px] text-[19px] leading-[1.5] text-[#1c2020]/65">
                Contracts are written to sound reasonable. That is what makes the costly bits so easy to miss. Redline pulls them into the light, translates the legalese, and gives you a next move you can actually use.
              </p>
            </div>
          </div>
        </Reveal>
        <div className="grid grid-cols-1 gap-0 md:grid-cols-3">
          {[
            { n: "01", icon: ScanSearch, title: "Spot the sharp edges", body: "Upload a contract and Redline scans for the five clauses most likely to leave a freelancer exposed." },
            { n: "02", icon: PenLine, title: "Understand the trade", body: "See what the clause says in plain English, why it matters for your project, and what a fair version looks like." },
            { n: "03", icon: Flag, title: "Ask for the fix", body: "Take the suggested question straight to your client. No bluffing. No legal theater. Just a better starting point." },
          ].map(({ n, icon: Icon, title, body }, index) => (
            <Reveal key={n} delay={index * 100} className="h-full">
              <div className={`h-full border-b border-[#1c2020]/20 py-8 md:border-b-0 md:py-12 md:pr-10 ${index > 0 ? "md:border-l md:pl-10" : ""}`}>
                <div className="mb-16 flex items-start justify-between">
                  <span className="redline-mono text-[11px] font-bold text-[#ef493b]">{n}</span>
                  <Icon size={23} strokeWidth={1.5} />
                </div>
                <h3 className="redline-serif text-[32px] leading-none">{title}</h3>
                <p className="mt-4 max-w-[290px] text-[14px] leading-[1.55] text-[#1c2020]/60">{body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="risk-index" className="bg-[#d8e0d5] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-[1320px]">
          <Reveal>
            <div className="mb-14 flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
              <div>
                <div className="redline-mono mb-4 text-[10px] font-bold uppercase tracking-[0.15em] text-[#ef493b]">02 — Risk index</div>
                <h2 className="redline-serif max-w-[700px] text-[clamp(3.4rem,7vw,7rem)] leading-[.85] tracking-[-.045em]">The usual<br /><span className="text-[#ef493b]">suspects.</span></h2>
              </div>
              <p className="max-w-[310px] text-[15px] leading-[1.5] text-[#1c2020]/65">Not every unusual sentence is a problem. These are the ones that deserve a pause before your signature.</p>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-[.8fr_1.2fr]">
            <Reveal delay={80}>
              <div className="border-t-2 border-[#1c2020]">
                {risks.map((risk) => (
                  <button key={risk.id} type="button" onClick={() => setActiveRisk(risk.id)} className={`group flex w-full items-center justify-between border-b border-[#1c2020]/20 py-5 text-left transition-colors ${activeRisk === risk.id ? "text-[#ef493b]" : "text-[#1c2020] hover:text-[#ef493b]"}`}>
                    <span className="flex items-center gap-5">
                      <span className="redline-mono text-[10px] text-[#1c2020]/45">{risk.number}</span>
                      <span className="text-[17px] font-bold">{risk.title}</span>
                    </span>
                    <ChevronRight size={18} className={`transition-transform ${activeRisk === risk.id ? "translate-x-1" : ""}`} />
                  </button>
                ))}
              </div>
              <div className="mt-8 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/55">
                <CircleCheck size={16} className="text-[#ef493b]" /> Five checks. One calmer signature.
              </div>
            </Reveal>
            <Reveal delay={160}>
              <div className="relative min-h-[390px] border border-[#1c2020] bg-[#f5eee4] p-6 sm:p-9">
                <div className="absolute right-5 top-5 text-[#ef493b]"><CircleAlert size={19} /></div>
                <div className="redline-mono mb-5 text-[10px] font-bold uppercase tracking-[0.14em] text-[#ef493b]">{selectedRisk.number} / {selectedRisk.short}</div>
                <h3 className="redline-serif max-w-[480px] text-[42px] leading-[.92] tracking-[-.025em]">{selectedRisk.title}</h3>
                <div className="mt-8 border-l-2 border-[#ef493b] pl-5">
                  <div className="redline-mono mb-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/45">What the clause says</div>
                  <p className="font-serif text-[17px] leading-[1.65] text-[#1c2020]/75">{selectedRisk.clause}</p>
                </div>
                <div className="mt-7 grid grid-cols-1 gap-5 border-t border-[#1c2020]/15 pt-6 sm:grid-cols-2">
                  <div>
                    <div className="redline-mono mb-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/45">Why it matters</div>
                    <p className="text-[13px] leading-[1.45] text-[#1c2020]/70">{selectedRisk.why}</p>
                  </div>
                  <div>
                    <div className="redline-mono mb-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/45">Your next step</div>
                    <p className="text-[13px] font-bold leading-[1.45] text-[#1c2020]">{selectedRisk.ask}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section id="analysis-preview" className="mx-auto max-w-[1320px] px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
        <Reveal>
          <div className="mb-12 max-w-[670px]">
            <div className="redline-mono mb-4 text-[10px] font-bold uppercase tracking-[0.15em] text-[#ef493b]">03 — Inside the read</div>
            <h2 className="redline-serif text-[clamp(3.3rem,6vw,6.5rem)] leading-[.86] tracking-[-.045em]">No panic.<br /><span className="text-[#ef493b]">Just specifics.</span></h2>
            <p className="mt-6 max-w-[510px] text-[17px] leading-[1.5] text-[#1c2020]/60">A Redline report is built to answer the question behind the question: “What do I say back?”</p>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <div className="redline-grid border border-[#1c2020] bg-[#eae1d5] p-3 sm:p-5 lg:p-8">
            <div className="grid grid-cols-1 border border-[#1c2020]/30 bg-[#f9f4ec] lg:grid-cols-[230px_1fr]">
              <aside className="border-b border-[#1c2020]/20 bg-[#e4dbcf] p-5 lg:border-b-0 lg:border-r">
                <div className="mb-8 flex items-center gap-2"><Logo /></div>
                <div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/45">Your read</div>
                <div className="mb-5 text-[14px] font-bold leading-[1.3]">Brand-partnership<br />agreement</div>
                <div className="space-y-1.5">
                  {risks.map((risk) => (
                    <button key={risk.id} type="button" onClick={() => setActiveRisk(risk.id)} className={`flex w-full items-center gap-2 px-2 py-2 text-left text-[11px] ${activeRisk === risk.id ? "bg-[#f5eee4] font-bold text-[#ef493b]" : "text-[#1c2020]/60 hover:text-[#ef493b]"}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${risk.tone === "critical" ? "bg-[#ef493b]" : "bg-[#d59c32]"}`} />
                      {risk.title}
                    </button>
                  ))}
                </div>
                <div className="mt-10 border-t border-[#1c2020]/15 pt-4">
                  <div className="redline-mono text-[9px] uppercase tracking-[0.1em] text-[#1c2020]/45">Overall read</div>
                  <div className="mt-1 text-[17px] font-bold">Worth a conversation</div>
                </div>
              </aside>
              <div className="p-5 sm:p-8 lg:p-10">
                <div className="mb-8 flex flex-wrap items-center justify-between gap-3 border-b border-[#1c2020]/15 pb-5">
                  <div>
                    <div className="redline-mono text-[9px] font-bold uppercase tracking-[0.13em] text-[#ef493b]">Risk 02 of 05</div>
                    <h3 className="mt-2 text-[21px] font-bold">Unlimited liability</h3>
                  </div>
                  <span className="flex items-center gap-2 border border-[#ef493b]/50 bg-[#f3ded5] px-3 py-2 text-[10px] font-bold uppercase tracking-[0.1em] text-[#c9382f]"><CircleAlert size={14} /> High attention</span>
                </div>
                <div className="grid grid-cols-1 gap-10 xl:grid-cols-[1fr_240px]">
                  <div>
                    <div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/45">The clause</div>
                    <HighlightedClause />
                    <div className="mt-8 border-t border-[#1c2020]/15 pt-6">
                      <div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[0.12em] text-[#1c2020]/45">What this means for you</div>
                      <p className="max-w-[600px] text-[15px] leading-[1.55] text-[#1c2020]/75">There is no dollar limit on what you could owe if someone claims your work caused a loss. The contract is asking you to carry all the risk for a fixed-fee project.</p>
                    </div>
                  </div>
                  <div className="h-fit border border-[#1c2020] bg-[#b8c7b6] p-5">
                    <div className="mb-4 flex items-center gap-2 text-[#ef493b]"><Sparkles size={16} /><span className="redline-mono text-[9px] font-bold uppercase tracking-[0.12em]">Try this next</span></div>
                    <p className="text-[15px] font-bold leading-[1.4]">“Would you be open to capping my total liability at the fees paid under this agreement?”</p>
                    <button type="button" onClick={() => navigator.clipboard?.writeText("Would you be open to capping my total liability at the fees paid under this agreement?")} className="mt-6 flex items-center gap-2 border-b border-[#1c2020]/50 pb-1 text-[10px] font-bold uppercase tracking-[0.1em] hover:border-[#ef493b] hover:text-[#ef493b]">Copy the question <ArrowRight size={13} /></button>
                  </div>
                </div>
                <div className="mt-10 flex flex-col gap-4 border-t border-[#1c2020]/15 pt-5 text-[11px] text-[#1c2020]/50 sm:flex-row sm:items-center sm:justify-between">
                  <span className="flex items-center gap-2"><Shield size={15} className="text-[#ef493b]" /> Educational, not legal advice.</span>
                  <span className="redline-mono">Last checked just now</span>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      <section className="bg-[#ef493b] px-5 py-24 text-[#fff8ed] sm:px-8 lg:px-12 lg:py-32">
        <Reveal>
          <div className="mx-auto grid max-w-[1320px] grid-cols-1 gap-12 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
            <div>
              <div className="redline-mono mb-5 text-[10px] font-bold uppercase tracking-[0.15em] text-[#1c2020]">The point</div>
              <blockquote className="redline-serif max-w-[850px] text-[clamp(3.2rem,6.6vw,7.3rem)] leading-[.86] tracking-[-.045em]">
                “You can be easy to work with without being easy to take advantage of.”
              </blockquote>
              <div className="mt-8 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.13em] text-[#1c2020]"><span className="h-px w-7 bg-[#1c2020]" /> Redline principle 01</div>
            </div>
            <div className="border-t border-[#1c2020]/30 pt-6 lg:border-l lg:border-t-0 lg:pl-10">
              <p className="max-w-[380px] text-[18px] leading-[1.45] text-[#1c2020]/80">The best negotiation is not a standoff. It is knowing exactly what you are asking for — before the pressure to “just sign” starts.</p>
            </div>
          </div>
        </Reveal>
      </section>

      <section id="pricing" className="mx-auto max-w-[1320px] px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
        <Reveal>
          <div className="mb-12 flex flex-col justify-between gap-7 md:flex-row md:items-end">
            <div>
              <div className="redline-mono mb-4 text-[10px] font-bold uppercase tracking-[0.15em] text-[#ef493b]">04 — Keep it fair</div>
              <h2 className="redline-serif text-[clamp(3.3rem,6vw,6.4rem)] leading-[.87] tracking-[-.045em]">A small read<br />for a <span className="text-[#ef493b]">big relief.</span></h2>
            </div>
            <p className="max-w-[300px] text-[15px] leading-[1.5] text-[#1c2020]/60">You should not have to spend the value of the project to understand the project.</p>
          </div>
        </Reveal>
        <Reveal delay={100}>
          <div className="grid grid-cols-1 border border-[#1c2020] bg-[#1c2020] text-[#f5eee4] lg:grid-cols-[1.1fr_.9fr]">
            <div className="p-7 sm:p-10 lg:p-14">
              <div className="redline-mono mb-16 text-[10px] font-bold uppercase tracking-[0.15em] text-[#ef493b]">One contract, one clear read</div>
              <div className="flex items-end gap-3"><span className="redline-serif text-[92px] leading-[.7] sm:text-[120px]">$12</span><span className="mb-1 text-[12px] text-[#f5eee4]/55">per contract<br />no subscription</span></div>
              <p className="mt-10 max-w-[430px] text-[17px] leading-[1.5] text-[#f5eee4]/70">Everything you need to decide whether to sign, ask, or walk away with your eyes open.</p>
              <button type="button" onClick={() => scrollTo("signup")} className="mt-9 flex items-center gap-3 bg-[#ef493b] px-5 py-4 text-[12px] font-bold uppercase tracking-[0.1em] text-[#fff8ed] transition-colors hover:bg-[#d83d33]">Start a contract read <MoveUpRight size={16} /></button>
            </div>
            <div className="border-t border-[#f5eee4]/15 bg-[#242b2a] p-7 sm:p-10 lg:border-l lg:border-t-0 lg:p-14">
              <div className="redline-mono mb-7 text-[10px] font-bold uppercase tracking-[0.15em] text-[#f5eee4]/50">Included, every time</div>
              <ul className="space-y-5">
                {["Plain-language summary of every flagged clause", "The five freelancer risk checks", "A practical question for your client", "Private document handling", "Downloadable report to keep"].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[15px] leading-[1.35]"><Check size={17} className="mt-0.5 shrink-0 text-[#ef493b]" /> {item}</li>
                ))}
              </ul>
              <div className="mt-12 border-t border-[#f5eee4]/15 pt-6 text-[11px] leading-[1.45] text-[#f5eee4]/45">Not legal advice. Redline helps you ask better questions; a licensed attorney can advise you on your specific situation.</div>
            </div>
          </div>
        </Reveal>
      </section>

      <section id="signup" className="bg-[#b8c7b6] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
        <Reveal>
          <div className="mx-auto max-w-[850px] text-center">
            <div className="mb-5 flex justify-center"><Fingerprint size={28} strokeWidth={1.5} /></div>
            <h2 className="redline-serif text-[clamp(3.2rem,7vw,7rem)] leading-[.85] tracking-[-.045em]">Keep your name<br /><span className="text-[#ef493b]">on your work.</span></h2>
            <p className="mx-auto mt-7 max-w-[470px] text-[17px] leading-[1.5] text-[#1c2020]/65">Get a first look at Redline, plus one plain-English contract tip in your inbox each week.</p>
            {submitted ? (
              <div className="mx-auto mt-9 flex max-w-[540px] items-center justify-center gap-3 border border-[#1c2020] bg-[#f5eee4] px-5 py-5 text-left text-[14px] font-bold"><CircleCheck className="text-[#ef493b]" /> You&apos;re on the list. We&apos;ll bring the good questions.</div>
            ) : (
              <form onSubmit={submitEmail} className="mx-auto mt-9 flex max-w-[540px] flex-col gap-2 sm:flex-row">
                <label className="sr-only" htmlFor="redline-email">Your email address</label>
                <input id="redline-email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@yourstudio.com" className="min-w-0 flex-1 border border-[#1c2020] bg-[#f5eee4] px-5 py-4 text-[14px] outline-none placeholder:text-[#1c2020]/35 focus:ring-2 focus:ring-[#ef493b]" />
                <button type="submit" className="flex items-center justify-center gap-2 bg-[#1c2020] px-6 py-4 text-[11px] font-bold uppercase tracking-[0.12em] text-[#f5eee4] transition-colors hover:bg-[#ef493b]">Get early access <ArrowRight size={15} /></button>
              </form>
            )}
            <p className="mt-4 text-[10px] uppercase tracking-[0.12em] text-[#1c2020]/45">No noise. Unsubscribe whenever.</p>
          </div>
        </Reveal>
      </section>

      <section className="mx-auto max-w-[980px] px-5 py-24 sm:px-8 lg:py-32">
        <Reveal>
          <div className="mb-10 flex items-end justify-between border-b border-[#1c2020]/20 pb-5">
            <div>
              <div className="redline-mono mb-3 text-[10px] font-bold uppercase tracking-[0.15em] text-[#ef493b]">05 — No dumb questions</div>
              <h2 className="redline-serif text-[clamp(3rem,6vw,5rem)] leading-[.88] tracking-[-.04em]">Good to know.</h2>
            </div>
            <span className="redline-mono hidden text-[10px] text-[#1c2020]/45 sm:block">The short version</span>
          </div>
        </Reveal>
        <div>
          {faqs.map((faq, index) => (
            <Reveal key={faq.question} delay={index * 60}>
              <div className="border-b border-[#1c2020]/20">
                <button type="button" onClick={() => setOpenFaq(openFaq === index ? -1 : index)} className="flex w-full items-center justify-between gap-5 py-6 text-left">
                  <span className="text-[17px] font-bold sm:text-[19px]">{faq.question}</span>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border border-[#1c2020]/30 transition-colors ${openFaq === index ? "bg-[#ef493b] text-[#fff8ed]" : ""}`}>{openFaq === index ? <Minus size={15} /> : <ChevronDown size={15} />}</span>
                </button>
                {openFaq === index && <div className="max-w-[680px] pb-7 pr-10 text-[15px] leading-[1.55] text-[#1c2020]/65">{faq.answer}</div>}
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <footer className="bg-[#1c2020] px-5 py-12 text-[#f5eee4] sm:px-8 lg:px-12">
        <div className="mx-auto flex max-w-[1320px] flex-col gap-10 sm:flex-row sm:items-end sm:justify-between">
          <div><Logo dark /><p className="mt-5 max-w-[280px] text-[12px] leading-[1.5] text-[#f5eee4]/45">The plain-language contract safety tool for people building their own thing.</p></div>
          <div className="flex flex-wrap gap-x-7 gap-y-3 text-[10px] font-bold uppercase tracking-[0.12em] text-[#f5eee4]/55"><button type="button" onClick={() => scrollTo("top")} className="hover:text-[#ef493b]">Back to top</button><button type="button" onClick={() => scrollTo("pricing")} className="hover:text-[#ef493b]">Pricing</button><button type="button" onClick={() => scrollTo("signup")} className="hover:text-[#ef493b]">Contact</button></div>
          <div className="redline-mono text-[9px] uppercase tracking-[0.1em] text-[#f5eee4]/35">© 2024 Redline App</div>
        </div>
      </footer>
    </main>
  );
}

export default RedlineLanding;