import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  Clock3,
  FileText,
  Menu,
  MoveUpRight,
  PenLine,
  Scale,
  Search,
  ShieldAlert,
  Sparkles,
  X,
} from "lucide-react";

type RiskTone = "high" | "medium";

type Risk = {
  id: string;
  number: string;
  icon: typeof Scale;
  title: string;
  short: string;
  clause: string;
  why: string;
  ask: string;
  tone: RiskTone;
  placement: "left" | "right";
};

const risks: Risk[] = [
  {
    id: "liability",
    number: "01",
    icon: Scale,
    title: "Unlimited liability",
    short: "The blank cheque",
    clause:
      "Contractor shall be liable for any and all losses, costs, claims, damages, and expenses arising out of or related to the Services, without limitation.",
    why: "A modest project should not expose your personal finances to an open-ended claim.",
    ask: "Cap your total liability at the fees paid under this agreement.",
    tone: "high",
    placement: "left",
  },
  {
    id: "payment",
    number: "02",
    icon: Clock3,
    title: "90-day payment terms",
    short: "The slow drip",
    clause:
      "Client shall pay Contractor within ninety (90) days of receipt of invoice, subject to Client acceptance of the Services.",
    why: "Ninety days is a quarter of a year to carry the cost of someone else's project.",
    ask: "Ask for 14-day payment terms, with no acceptance condition.",
    tone: "high",
    placement: "right",
  },
  {
    id: "ip",
    number: "03",
    icon: FileText,
    title: "Client owns your work",
    short: "Giving away the toolbox",
    clause:
      "All work product, including drafts, concepts, processes, and deliverables created by Contractor shall be the sole property of the Client.",
    why: "As written, the client could claim your reusable tools, methods, and work-in-progress.",
    ask: "Carve out pre-existing materials, tools, and general know-how.",
    tone: "high",
    placement: "left",
  },
  {
    id: "termination",
    number: "04",
    icon: ShieldAlert,
    title: "Termination without notice",
    short: "The one-way exit",
    clause:
      "Client may terminate this Agreement at any time, for any reason, upon written notice. Contractor shall be paid only for accepted work.",
    why: "They can leave whenever they want while your payment depends on a vague idea of acceptance.",
    ask: "Add 14 days' notice and payment for completed work plus committed costs.",
    tone: "medium",
    placement: "right",
  },
  {
    id: "renewal",
    number: "05",
    icon: ArrowRight,
    title: "Auto-renewal",
    short: "The quiet extension",
    clause:
      "This Agreement automatically renews for successive twelve (12) month periods unless either party gives written notice at least 60 days before term end.",
    why: "Miss the window and you may be committed for another year without noticing.",
    ask: "Change the notice period to 14 days, or remove automatic renewal.",
    tone: "medium",
    placement: "left",
  },
];

const faqs = [
  {
    question: "Is Redline legal advice?",
    answer:
      "No. Redline is a plain-language contract safety tool, not a lawyer or a substitute for legal advice. It helps you spot questions worth asking and gives you practical language for a conversation with a client or counsel.",
  },
  {
    question: "What does Redline actually check?",
    answer:
      "Every read looks for five recurring pressure points: liability, payment timing, ownership of work, termination, and restrictions or renewal. You get the relevant clause, a plain-English explanation, and a specific next question.",
  },
  {
    question: "Will it rewrite my whole contract?",
    answer:
      "Redline focuses on the clauses most likely to create an expensive surprise. You get a focused read, not a fog of tracked changes or a document pretending to be your lawyer.",
  },
  {
    question: "What happens to the contracts I upload?",
    answer:
      "Your documents are private to your account and used to generate your report. You can delete a document and its analysis whenever you like.",
  },
];

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node || typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.12 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return { ref, visible };
}

function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={`blind-reveal ${visible ? "blind-reveal-visible" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

function Brand() {
  return (
    <span className="flex items-center gap-2.5 text-[#181a19]" aria-label="Redline home">
      <span className="relative flex h-7 w-7 items-center justify-center border-[1.5px] border-current">
        <span className="h-3.5 w-3.5 bg-[#e33e35]" />
        <span className="absolute -right-[4px] -top-[4px] h-2 w-2 bg-[#181a19]" />
      </span>
      <span className="blind-mono text-[12px] font-bold uppercase tracking-[0.2em]">
        redline<span className="text-[#e33e35]">.</span>
      </span>
    </span>
  );
}

function PaperLines({ count = 4, widths = ["92%", "84%", "68%", "88%"] }: { count?: number; widths?: string[] }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: count }).map((_, index) => (
        <div
          key={index}
          className="h-[6px] bg-[#ded8cf]"
          style={{ width: widths[index % widths.length] }}
        />
      ))}
    </div>
  );
}

function Callout({ risk }: { risk: Risk }) {
  const Icon = risk.icon;
  return (
    <div
      className={`blind-callout blind-callout-${risk.placement} relative z-20 border border-[#a9a096] bg-[#faf6ef] px-4 py-3 shadow-[3px_4px_0_rgba(24,26,25,.08)]`}
    >
      <span className="blind-callout-line" aria-hidden="true" />
      <div className="flex items-start gap-2.5">
        <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#e33e35] text-[#fff9f0]">
          <Icon size={14} strokeWidth={1.8} />
        </span>
        <div>
          <div className="blind-mono text-[9px] font-bold uppercase leading-[1.25] tracking-[0.08em] text-[#b52f2c]">
            {risk.title}
          </div>
          <p className="mt-1.5 max-w-[165px] text-[11px] leading-[1.35] text-[#282b29]">
            {risk.id === "liability" && <>You could be liable for <strong className="text-[#e33e35]">any and all losses.</strong></>}
            {risk.id === "payment" && <>Payment is not due for up to <strong className="text-[#e33e35]">90 days.</strong></>}
            {risk.id === "ip" && <>All deliverables become the <strong className="text-[#e33e35]">property of the client.</strong></>}
            {risk.id === "termination" && <>They can end the agreement <strong className="text-[#e33e35]">at any time.</strong></>}
            {risk.id === "renewal" && <>The agreement quietly <strong className="text-[#e33e35]">renews itself.</strong></>}
          </p>
        </div>
      </div>
    </div>
  );
}

function Agreement() {
  return (
    <div className="blind-agreement relative border border-[#b9b0a5] bg-[#fcf9f3] p-5 shadow-[11px_13px_0_rgba(25,25,22,.13)] sm:p-7 lg:p-9">
      <div className="absolute -right-3 -top-3 h-full w-full border border-[#cbc2b7] bg-[#f5f0e8]" aria-hidden="true" />
      <div className="relative">
        <div className="mb-6 flex items-center justify-between border-b border-[#202321]/20 pb-4">
          <div className="flex items-center gap-2">
            <FileText size={16} className="text-[#e33e35]" />
            <span className="blind-mono text-[8px] font-bold uppercase tracking-[0.14em] sm:text-[9px]">
              website_redesign_agreement.pdf
            </span>
          </div>
          <span className="blind-mono text-[8px] text-[#202321]/50">6 pages</span>
        </div>
        <div className="mb-6 text-center">
          <div className="blind-mono mb-4 text-[10px] font-bold uppercase tracking-[0.18em]">Agreement</div>
          <div className="mx-auto h-[7px] w-[34%] bg-[#a6a198]" />
        </div>
        <div className="space-y-6 text-[10px] leading-[1.5] text-[#3b3b37] sm:text-[11px]">
          <div className="grid grid-cols-[22px_1fr_1fr] gap-2">
            <span className="blind-mono text-[#77736c]">8.</span>
            <p>
              Contractor shall be liable for <mark>any and all losses</mark>, costs, claims, damages, and expenses arising out of or related to the Services, <mark className="strong">without limitation.</mark>
            </p>
            <PaperLines count={3} widths={["90%", "82%", "70%"]} />
          </div>
          <div className="grid grid-cols-[22px_1fr_1fr] gap-2">
            <span className="blind-mono text-[#77736c]">9.</span>
            <PaperLines count={3} widths={["95%", "74%", "86%"]} />
            <p>
              Client shall pay Contractor within <mark>ninety (90) days</mark> of receipt of invoice.
            </p>
          </div>
          <div className="grid grid-cols-[22px_1fr_1fr] gap-2">
            <span className="blind-mono text-[#77736c]">11.</span>
            <p>
              All work product, including drafts and concepts, shall be the <mark>sole property of the Client.</mark>
            </p>
            <PaperLines count={3} widths={["86%", "92%", "60%"]} />
          </div>
          <div className="grid grid-cols-[22px_1fr_1fr] gap-2">
            <span className="blind-mono text-[#77736c]">14.</span>
            <PaperLines count={2} widths={["74%", "56%"]} />
            <p>
              Client may terminate this Agreement <mark>at any time, with or without cause or notice.</mark>
            </p>
          </div>
        </div>
        <div className="mt-7 border-t border-[#202321]/15 pt-5">
          <PaperLines count={3} widths={["93%", "87%", "46%"]} />
        </div>
        <div className="mt-8 flex items-end justify-between border-t border-[#202321]/15 pt-4">
          <div>
            <div className="blind-mono text-[8px] font-bold uppercase tracking-[0.12em] text-[#e33e35]">Redline read</div>
            <div className="mt-1 text-[11px] font-bold sm:text-[12px]">Worth a conversation.</div>
          </div>
          <div className="flex h-8 w-8 items-center justify-center border border-[#e33e35] text-[#e33e35]">
            <ArrowDown size={16} />
          </div>
        </div>
      </div>
    </div>
  );
}

export function RedlineBlind() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeRisk, setActiveRisk] = useState("liability");
  const [openFaq, setOpenFaq] = useState(0);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const selectedRisk = risks.find((risk) => risk.id === activeRisk) ?? risks[0];

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const submitEmail = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (email.trim()) setSubmitted(true);
  };

  return (
    <main className="redline-blind min-h-[100dvh] overflow-hidden bg-[#f3ede4] text-[#181a19]">
      <style>{`
        .redline-blind {
          --blind-ink: #181a19;
          --blind-paper: #f3ede4;
          --blind-red: #e33e35;
          --blind-sage: #c9d4c5;
          font-family: "DM Sans", "Avenir Next", sans-serif;
          background-image: radial-gradient(rgba(24,26,25,.045) .7px, transparent .7px);
          background-size: 6px 6px;
        }
        .redline-blind *, .redline-blind *::before, .redline-blind *::after { box-sizing: border-box; }
        .blind-serif { font-family: "Instrument Serif", Georgia, serif; }
        .blind-mono { font-family: "Space Mono", "SFMono-Regular", monospace; }
        .blind-reveal { opacity: 0; transform: translateY(22px); transition: opacity .7s ease, transform .7s cubic-bezier(.22,1,.36,1); }
        .blind-reveal-visible { opacity: 1; transform: translateY(0); }
        .redline-blind mark { background: linear-gradient(transparent 48%, rgba(227,62,53,.38) 48%); color: inherit; padding: 0 2px; }
        .redline-blind mark.strong { background: linear-gradient(transparent 38%, rgba(227,62,53,.72) 38%); }
        .blind-paper-grid { background-image: linear-gradient(rgba(24,26,25,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(24,26,25,.08) 1px, transparent 1px); background-size: 24px 24px; }
        .blind-agreement { transform: rotate(1.6deg); }
        .blind-callout-line { position: absolute; height: 1px; background: #e33e35; top: 50%; width: 78px; }
        .blind-callout-left .blind-callout-line { right: -78px; }
        .blind-callout-right .blind-callout-line { left: -78px; }
        .blind-callout-left .blind-callout-line::after, .blind-callout-right .blind-callout-line::after { content: ""; position: absolute; top: -3px; width: 7px; height: 7px; border-radius: 999px; background: #e33e35; }
        .blind-callout-left .blind-callout-line::after { right: -2px; }
        .blind-callout-right .blind-callout-line::after { left: -2px; }
        .blind-nav-link { transition: color .2s ease; }
        .blind-nav-link:hover { color: #e33e35; }
        .blind-button { transition: background-color .2s ease, transform .2s ease; }
        .blind-button:hover { background-color: #b92f2b; transform: translateY(-2px); }
        .blind-button:active { transform: translateY(0); }
        .blind-text-link svg { transition: transform .2s ease; }
        .blind-text-link:hover svg { transform: translate(4px, -3px); }
        .blind-faq-answer { display: grid; grid-template-rows: 0fr; transition: grid-template-rows .3s ease; }
        .blind-faq-answer.open { grid-template-rows: 1fr; }
        .blind-faq-answer > div { overflow: hidden; }
        @media (max-width: 1023px) {
          .blind-callout-line { display: none; }
        }
        @media (max-width: 767px) {
          .blind-agreement { transform: rotate(.7deg); }
        }
        @media (prefers-reduced-motion: reduce) {
          .blind-reveal { opacity: 1; transform: none; transition: none; }
          .blind-button, .blind-nav-link, .blind-text-link svg, .blind-faq-answer { transition: none; }
        }
      `}</style>

      <div className="bg-[#181a19] px-4 py-2 text-center text-[9px] font-bold uppercase tracking-[0.17em] text-[#f3ede4] sm:text-[10px]">
        Built for the people who sign the work <span className="mx-2 text-[#e33e35]">/</span> No legal degree required
      </div>

      <header className="relative z-40 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-5 sm:px-8 lg:px-10">
        <button type="button" onClick={() => scrollTo("top")} aria-label="Back to top">
          <Brand />
        </button>
        <nav className="hidden items-center gap-8 text-[11px] font-bold uppercase tracking-[0.14em] text-[#181a19]/70 lg:flex">
          <button type="button" className="blind-nav-link" onClick={() => scrollTo("how-it-works")}>How it works</button>
          <button type="button" className="blind-nav-link" onClick={() => scrollTo("risk-index")}>What it catches</button>
          <button type="button" className="blind-nav-link" onClick={() => scrollTo("pricing")}>Pricing</button>
          <button type="button" className="blind-nav-link" onClick={() => scrollTo("for-freelancers")}>For freelancers</button>
        </nav>
        <div className="hidden items-center gap-5 lg:flex">
          <button type="button" className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#181a19]/70 transition-colors hover:text-[#e33e35]" onClick={() => scrollTo("signup")}>Sign in</button>
          <button type="button" className="blind-button flex items-center gap-2 bg-[#e33e35] px-4 py-3 text-[11px] font-bold uppercase tracking-[0.13em] text-[#fff9f0]" onClick={() => scrollTo("signup")}>
            Try Redline <ArrowRight size={14} />
          </button>
        </div>
        <button type="button" className="p-2 lg:hidden" onClick={() => setMobileOpen((open) => !open)} aria-label="Toggle menu" aria-expanded={mobileOpen}>
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
        {mobileOpen && (
          <div className="absolute left-5 right-5 top-[70px] border border-[#181a19] bg-[#f3ede4] p-5 shadow-[7px_7px_0_#e33e35] lg:hidden">
            <div className="flex flex-col gap-5 text-left text-[11px] font-bold uppercase tracking-[0.14em]">
              <button type="button" onClick={() => scrollTo("how-it-works")}>How it works</button>
              <button type="button" onClick={() => scrollTo("risk-index")}>What it catches</button>
              <button type="button" onClick={() => scrollTo("pricing")}>Pricing</button>
              <button type="button" onClick={() => scrollTo("for-freelancers")}>For freelancers</button>
              <button type="button" className="border-t border-[#181a19]/20 pt-5 text-left text-[#e33e35]" onClick={() => scrollTo("signup")}>Start your read <ArrowRight className="ml-1 inline" size={14} /></button>
            </div>
          </div>
        )}
      </header>

      <section id="top" className="mx-auto max-w-[1240px] px-5 pb-14 pt-5 text-center sm:px-8 lg:px-10 lg:pb-16 lg:pt-7">
        <Reveal>
          <div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.18em] text-[#e33e35] sm:mb-5">Contract clarity for the self-employed</div>
        </Reveal>
        <Reveal delay={80}>
          <h1 className="blind-serif text-[clamp(4.25rem,10.2vw,9.2rem)] leading-[.78] tracking-[-.055em]">
            Don&apos;t sign <span className="text-[#e33e35]">blind.</span>
          </h1>
        </Reveal>
        <Reveal delay={150}>
          <p className="mx-auto mt-5 max-w-[510px] text-[15px] leading-[1.45] text-[#181a19]/70 sm:text-[17px]">
            Know what you&apos;re agreeing to before your signature hits the page.
          </p>
        </Reveal>
        <Reveal delay={220}>
          <div className="mt-7 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <button type="button" className="blind-button flex items-center gap-2 bg-[#e33e35] px-5 py-3.5 text-[11px] font-bold uppercase tracking-[0.13em] text-[#fff9f0]" onClick={() => scrollTo("signup")}>
              Read my contract <MoveUpRight size={14} />
            </button>
            <button type="button" className="blind-text-link flex items-center gap-2 border-b border-[#181a19]/45 pb-1 text-[11px] font-bold uppercase tracking-[0.13em]" onClick={() => scrollTo("analysis-preview")}>
              See a real read <ArrowRight size={14} />
            </button>
          </div>
        </Reveal>

        <Reveal delay={300} className="relative mx-auto mt-12 max-w-[1040px] lg:mt-14">
          <div className="absolute -left-1 top-[8%] hidden w-[182px] lg:block xl:-left-4"><Callout risk={risks[0]} /></div>
          <div className="absolute -left-1 top-[47%] hidden w-[182px] lg:block xl:-left-4"><Callout risk={risks[2]} /></div>
          <div className="absolute -right-1 top-[18%] hidden w-[182px] lg:block xl:-right-4"><Callout risk={risks[1]} /></div>
          <div className="absolute -right-1 top-[59%] hidden w-[182px] lg:block xl:-right-4"><Callout risk={risks[3]} /></div>
          <div className="relative mx-auto max-w-[780px]">
            <Agreement />
            <div className="absolute -bottom-7 right-[-3%] z-30 rotate-[-4deg] border border-[#9ba898] bg-[#c9d4c5] px-4 py-3 text-left shadow-[4px_4px_0_rgba(24,26,25,.12)] sm:right-[-6%]">
              <div className="blind-mono text-[8px] font-bold uppercase tracking-[0.13em]">Risk level</div>
              <div className="mt-1 flex items-center gap-2 text-[13px] font-bold"><span className="h-2 w-2 rounded-full bg-[#e33e35]" /> Worth a conversation</div>
            </div>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-3 text-left sm:grid-cols-2 lg:hidden">
            {risks.slice(0, 4).map((risk) => <Callout key={risk.id} risk={risk} />)}
          </div>
        </Reveal>
      </section>

      <div className="border-y border-[#f3ede4]/20 bg-[#181a19] text-[#f3ede4]">
        <div className="mx-auto grid max-w-[1240px] grid-cols-2 sm:grid-cols-4">
          {[
            ["$2,000", "average project protected"],
            ["5", "high-stakes risks surfaced"],
            ["3 min", "to your first clear question"],
            ["$0", "lawyer-shaped price tag"],
          ].map(([value, label], index) => (
            <div key={label} className={`border-[#f3ede4]/15 px-4 py-6 sm:px-6 sm:py-7 ${index % 2 === 0 ? "border-r" : ""} ${index > 1 ? "border-t sm:border-t-0" : ""}`}>
              <div className="blind-serif text-[32px] leading-none text-[#e33e35] sm:text-[40px]">{value}</div>
              <div className="mt-2 max-w-[145px] text-[9px] font-bold uppercase leading-[1.35] tracking-[0.13em] text-[#f3ede4]/60">{label}</div>
            </div>
          ))}
        </div>
      </div>

      <section id="how-it-works" className="mx-auto max-w-[1240px] px-5 py-24 sm:px-8 lg:px-10 lg:py-32">
        <Reveal>
          <div className="grid gap-8 border-b border-[#181a19]/20 pb-12 lg:grid-cols-[.85fr_1.15fr] lg:gap-20">
            <div>
              <div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.16em] text-[#e33e35]">01 — The approach</div>
              <h2 className="blind-serif max-w-[550px] text-[clamp(3.4rem,6.5vw,6.6rem)] leading-[.82] tracking-[-.045em]">A second set of eyes. <span className="text-[#e33e35]">A sharper voice.</span></h2>
            </div>
            <div className="flex items-end">
              <p className="max-w-[575px] text-[17px] leading-[1.55] text-[#181a19]/68 sm:text-[19px]">
                Contracts are written to sound reasonable. That is what makes the costly bits so easy to miss. Redline pulls them into the light, translates the legalese, and gives you a next move you can actually use.
              </p>
            </div>
          </div>
        </Reveal>
        <div className="grid md:grid-cols-3">
          {[
            { n: "01", icon: Search, title: "Spot the sharp edges", body: "Upload a contract and Redline scans for the five clauses most likely to leave a freelancer exposed." },
            { n: "02", icon: PenLine, title: "Understand the trade", body: "See what the clause says in plain English, why it matters for your project, and what a fair version looks like." },
            { n: "03", icon: Sparkles, title: "Ask for the fix", body: "Take the suggested question straight to your client. No bluffing. No legal theater. Just a better starting point." },
          ].map(({ n, icon: Icon, title, body }, index) => (
            <Reveal key={n} delay={index * 100} className="h-full">
              <div className={`h-full border-b border-[#181a19]/20 py-8 md:border-b-0 md:py-12 md:pr-10 ${index > 0 ? "md:border-l md:pl-10" : ""}`}>
                <div className="mb-14 flex items-start justify-between"><span className="blind-mono text-[10px] font-bold text-[#e33e35]">{n}</span><Icon size={22} strokeWidth={1.6} /></div>
                <h3 className="blind-serif text-[32px] leading-none">{title}</h3>
                <p className="mt-4 max-w-[300px] text-[14px] leading-[1.55] text-[#181a19]/62">{body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="risk-index" className="bg-[#c9d4c5] px-5 py-24 sm:px-8 lg:px-10 lg:py-32">
        <div className="mx-auto max-w-[1240px]">
          <Reveal>
            <div className="mb-14 flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
              <div>
                <div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.16em] text-[#e33e35]">02 — Risk index</div>
                <h2 className="blind-serif text-[clamp(3.7rem,7.5vw,7.4rem)] leading-[.8] tracking-[-.05em]">The usual<br /><span className="text-[#e33e35]">suspects.</span></h2>
              </div>
              <p className="max-w-[315px] text-[14px] leading-[1.55] text-[#181a19]/65">Not every unusual sentence is a problem. These are the ones that deserve a pause before your signature.</p>
            </div>
          </Reveal>
          <div className="grid gap-10 lg:grid-cols-[.78fr_1.22fr]">
            <Reveal delay={80}>
              <div className="border-t-2 border-[#181a19]">
                {risks.map((risk) => (
                  <button key={risk.id} type="button" onClick={() => setActiveRisk(risk.id)} className={`group flex w-full items-center justify-between border-b border-[#181a19]/20 py-5 text-left transition-colors hover:text-[#e33e35] ${activeRisk === risk.id ? "text-[#e33e35]" : ""}`}>
                    <span className="flex items-center gap-5"><span className="blind-mono text-[10px] text-[#181a19]/45">{risk.number}</span><span className="text-[16px] font-bold">{risk.title}</span></span>
                    <ChevronRight size={17} className={`transition-transform ${activeRisk === risk.id ? "translate-x-1" : ""}`} />
                  </button>
                ))}
              </div>
              <div className="mt-8 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.13em] text-[#181a19]/60"><CircleCheck size={16} className="text-[#e33e35]" /> Five checks. One calmer signature.</div>
            </Reveal>
            <Reveal delay={150}>
              <div className="relative border border-[#181a19] bg-[#f3ede4] p-6 sm:p-9">
                <CircleAlert size={18} className="absolute right-5 top-5 text-[#e33e35]" />
                <div className="blind-mono mb-5 text-[9px] font-bold uppercase tracking-[0.14em] text-[#e33e35]">{selectedRisk.number} / {selectedRisk.short}</div>
                <h3 className="blind-serif text-[43px] leading-[.88] tracking-[-.03em]">{selectedRisk.title}</h3>
                <div className="mt-8 border-l-2 border-[#e33e35] pl-5">
                  <div className="blind-mono mb-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#181a19]/45">What the clause says</div>
                  <p className="blind-serif text-[19px] leading-[1.45] text-[#181a19]/75">{selectedRisk.clause}</p>
                </div>
                <div className="mt-7 grid gap-5 border-t border-[#181a19]/15 pt-6 sm:grid-cols-2">
                  <div><div className="blind-mono mb-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#181a19]/45">Why it matters</div><p className="text-[13px] leading-[1.5] text-[#181a19]/70">{selectedRisk.why}</p></div>
                  <div><div className="blind-mono mb-2 text-[9px] font-bold uppercase tracking-[0.12em] text-[#181a19]/45">Your next step</div><p className="text-[13px] font-bold leading-[1.5]">{selectedRisk.ask}</p></div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section id="analysis-preview" className="mx-auto max-w-[1240px] px-5 py-24 sm:px-8 lg:px-10 lg:py-32">
        <Reveal>
          <div className="mb-12 max-w-[680px]">
            <div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.16em] text-[#e33e35]">03 — Inside the read</div>
            <h2 className="blind-serif text-[clamp(3.6rem,6.8vw,6.8rem)] leading-[.82] tracking-[-.05em]">No panic.<br /><span className="text-[#e33e35]">Just specifics.</span></h2>
            <p className="mt-6 max-w-[510px] text-[16px] leading-[1.55] text-[#181a19]/63">A Redline report is built to answer the question behind the question: “What do I say back?”</p>
          </div>
        </Reveal>
        <Reveal delay={100}>
          <div className="blind-paper-grid border border-[#181a19] bg-[#e8dfd4] p-3 sm:p-5 lg:p-8">
            <div className="grid border border-[#181a19]/25 bg-[#fcf9f3] lg:grid-cols-[220px_1fr]">
              <aside className="border-b border-[#181a19]/20 bg-[#e3dbd0] p-5 lg:border-b-0 lg:border-r">
                <Brand />
                <div className="blind-mono mb-3 mt-9 text-[9px] font-bold uppercase tracking-[0.12em] text-[#181a19]/45">Your read</div>
                <div className="text-[14px] font-bold leading-[1.3]">Brand-partnership<br />agreement</div>
                <div className="mt-5 space-y-1">
                  {risks.map((risk) => (
                    <button key={risk.id} type="button" onClick={() => setActiveRisk(risk.id)} className={`flex w-full items-center gap-2 px-2 py-2 text-left text-[11px] ${activeRisk === risk.id ? "bg-[#f3ede4] font-bold text-[#e33e35]" : "text-[#181a19]/60 hover:text-[#e33e35]"}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${risk.tone === "high" ? "bg-[#e33e35]" : "bg-[#d49538]"}`} />{risk.title}
                    </button>
                  ))}
                </div>
                <div className="mt-9 border-t border-[#181a19]/15 pt-4"><div className="blind-mono text-[8px] uppercase tracking-[0.1em] text-[#181a19]/45">Overall read</div><div className="mt-1 text-[16px] font-bold">Worth a conversation</div></div>
              </aside>
              <div className="p-5 sm:p-8 lg:p-10">
                <div className="mb-8 flex flex-wrap items-center justify-between gap-3 border-b border-[#181a19]/15 pb-5">
                  <div><div className="blind-mono text-[9px] font-bold uppercase tracking-[0.13em] text-[#e33e35]">Risk {selectedRisk.number} of 05</div><h3 className="mt-2 text-[21px] font-bold">{selectedRisk.title}</h3></div>
                  <span className="flex items-center gap-2 border border-[#e33e35]/50 bg-[#f1d9d1] px-3 py-2 text-[9px] font-bold uppercase tracking-[0.1em] text-[#b52f2c]"><CircleAlert size={13} /> {selectedRisk.tone === "high" ? "High attention" : "Worth a look"}</span>
                </div>
                <div className="grid gap-10 xl:grid-cols-[1fr_240px]">
                  <div>
                    <div className="blind-mono mb-3 text-[9px] font-bold uppercase tracking-[0.12em] text-[#181a19]/45">The clause</div>
                    <p className="blind-serif text-[20px] leading-[1.65] text-[#343631]">{selectedRisk.clause}</p>
                    <div className="mt-8 border-t border-[#181a19]/15 pt-6"><div className="blind-mono mb-3 text-[9px] font-bold uppercase tracking-[0.12em] text-[#181a19]/45">What this means for you</div><p className="max-w-[600px] text-[14px] leading-[1.6] text-[#181a19]/72">{selectedRisk.why}</p></div>
                  </div>
                  <div className="h-fit border border-[#181a19] bg-[#c9d4c5] p-5">
                    <div className="mb-4 flex items-center gap-2 text-[#e33e35]"><Sparkles size={15} /><span className="blind-mono text-[9px] font-bold uppercase tracking-[0.12em]">Try this next</span></div>
                    <p className="text-[14px] font-bold leading-[1.5]">{selectedRisk.ask}</p>
                    <button type="button" className="mt-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.1em] text-[#e33e35] hover:underline" onClick={() => setActiveRisk(risks[(risks.findIndex((risk) => risk.id === activeRisk) + 1) % risks.length].id)}>Next risk <ArrowRight size={13} /></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      <section id="pricing" className="border-y border-[#181a19]/20 bg-[#e8dfd4] px-5 py-24 sm:px-8 lg:px-10 lg:py-28">
        <div className="mx-auto grid max-w-[1240px] items-end gap-12 lg:grid-cols-[1fr_1fr]">
          <Reveal>
            <div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.16em] text-[#e33e35]">04 — Keep it fair</div>
            <h2 className="blind-serif max-w-[590px] text-[clamp(3.6rem,7vw,7rem)] leading-[.8] tracking-[-.05em]">A small fee<br />for a <span className="text-[#e33e35]">big pause.</span></h2>
            <p className="mt-7 max-w-[425px] text-[16px] leading-[1.55] text-[#181a19]/65">One clear read costs less than one overlooked clause. Start before the signature, not after the problem.</p>
          </Reveal>
          <Reveal delay={100}>
            <div className="border border-[#181a19] bg-[#f3ede4] p-6 shadow-[7px_7px_0_#c9d4c5] sm:p-8">
              <div className="flex items-start justify-between border-b border-[#181a19]/15 pb-6"><div><div className="blind-mono text-[9px] font-bold uppercase tracking-[0.13em] text-[#e33e35]">The freelancer read</div><h3 className="mt-3 blind-serif text-[39px] leading-none">One contract</h3></div><div className="blind-serif text-[46px] leading-none">$12</div></div>
              <ul className="space-y-3 py-6 text-[13px] text-[#181a19]/75">
                {["Five high-stakes risk checks", "Plain-language explanations", "A specific question for each risk", "Private, downloadable report"].map((item) => <li key={item} className="flex items-center gap-3"><Check size={15} className="text-[#e33e35]" />{item}</li>)}
              </ul>
              <button type="button" className="blind-button flex w-full items-center justify-center gap-2 bg-[#e33e35] px-5 py-4 text-[11px] font-bold uppercase tracking-[0.13em] text-[#fff9f0]" onClick={() => scrollTo("signup")}>Start a read <MoveUpRight size={14} /></button>
              <p className="mt-4 text-center text-[10px] text-[#181a19]/50">No subscription. No lawyer-shaped price tag.</p>
            </div>
          </Reveal>
        </div>
      </section>

      <section id="for-freelancers" className="mx-auto max-w-[1240px] px-5 py-24 sm:px-8 lg:px-10 lg:py-32">
        <Reveal>
          <div className="grid gap-10 border-b border-[#181a19]/20 pb-12 lg:grid-cols-[.9fr_1.1fr]">
            <div><div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.16em] text-[#e33e35]">For the self-employed</div><h2 className="blind-serif max-w-[520px] text-[clamp(3.4rem,6vw,6.2rem)] leading-[.83] tracking-[-.045em]">You can be<br /><span className="text-[#e33e35]">easy to work with</span><br />without being easy to exploit.</h2></div>
            <div className="flex items-end"><p className="max-w-[530px] text-[18px] leading-[1.55] text-[#181a19]/67">For designers, developers, strategists, photographers, writers, producers, and consultants. If your name is on the agreement, Redline is for you.</p></div>
          </div>
        </Reveal>
        <div className="mx-auto mt-12 max-w-[780px] divide-y divide-[#181a19]/20 border-y border-[#181a19]/20">
          {faqs.map((faq, index) => (
            <div key={faq.question}>
              <button type="button" className="flex w-full items-center justify-between py-5 text-left" onClick={() => setOpenFaq(openFaq === index ? -1 : index)} aria-expanded={openFaq === index}>
                <span className="text-[15px] font-bold">{faq.question}</span><ChevronDown size={18} className={`transition-transform ${openFaq === index ? "rotate-180 text-[#e33e35]" : ""}`} />
              </button>
              <div className={`blind-faq-answer ${openFaq === index ? "open" : ""}`}><div><p className="max-w-[660px] pb-5 pr-8 text-[14px] leading-[1.55] text-[#181a19]/65">{faq.answer}</p></div></div>
            </div>
          ))}
        </div>
      </section>

      <section id="signup" className="bg-[#181a19] px-5 py-24 text-[#f3ede4] sm:px-8 lg:px-10 lg:py-32">
        <div className="mx-auto grid max-w-[1240px] gap-12 lg:grid-cols-[1fr_.85fr] lg:items-end">
          <Reveal>
            <div className="blind-mono mb-4 text-[9px] font-bold uppercase tracking-[0.16em] text-[#e33e35]">05 — Before you sign</div>
            <h2 className="blind-serif max-w-[720px] text-[clamp(4rem,8vw,8rem)] leading-[.78] tracking-[-.055em]">Make the<br /><span className="text-[#e33e35]">next move.</span></h2>
            <p className="mt-8 max-w-[470px] text-[16px] leading-[1.55] text-[#f3ede4]/65">Bring the contract. Leave with a clearer read and a fair question to send back.</p>
          </Reveal>
          <Reveal delay={100}>
            {submitted ? (
              <div className="border border-[#c9d4c5]/50 bg-[#c9d4c5] p-6 text-[#181a19] sm:p-8"><CircleCheck className="mb-5 text-[#e33e35]" size={27} /><h3 className="blind-serif text-[36px] leading-none">You&apos;re on the list.</h3><p className="mt-3 max-w-[330px] text-[14px] leading-[1.5] text-[#181a19]/70">We&apos;ll send the door over when Redline is ready for your next agreement.</p></div>
            ) : (
              <form onSubmit={submitEmail} className="border border-[#f3ede4]/35 p-5 sm:p-7">
                <div className="blind-mono mb-5 text-[9px] font-bold uppercase tracking-[0.13em] text-[#f3ede4]/55">Get first read access</div>
                <label htmlFor="blind-email" className="mb-2 block text-[13px] text-[#f3ede4]/75">Your email</label>
                <div className="flex flex-col gap-3 sm:flex-row"><input id="blind-email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@studio.com" className="min-w-0 flex-1 border border-[#f3ede4]/35 bg-transparent px-4 py-3 text-[14px] text-[#f3ede4] outline-none placeholder:text-[#f3ede4]/35 focus:border-[#e33e35]" /><button type="submit" className="blind-button flex items-center justify-center gap-2 bg-[#e33e35] px-5 py-3 text-[11px] font-bold uppercase tracking-[0.12em] text-[#fff9f0]">Get access <ArrowRight size={14} /></button></div>
                <p className="mt-4 text-[10px] leading-[1.45] text-[#f3ede4]/40">No sales sequence. Just a note when your next contract deserves a second look.</p>
              </form>
            )}
          </Reveal>
        </div>
      </section>

      <footer className="bg-[#181a19] px-5 pb-8 text-[#f3ede4] sm:px-8 lg:px-10">
        <div className="mx-auto flex max-w-[1240px] flex-col gap-5 border-t border-[#f3ede4]/15 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <span className="[&>span]:text-[#f3ede4]"><Brand /></span>
          <div className="blind-mono text-[9px] uppercase tracking-[0.12em] text-[#f3ede4]/40">Plain language for people doing the work.</div>
          <div className="text-[10px] text-[#f3ede4]/40">© 2026 Redline</div>
        </div>
      </footer>
    </main>
  );
}

export default RedlineBlind;