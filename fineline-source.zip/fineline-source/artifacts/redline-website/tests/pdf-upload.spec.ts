import { test, expect } from '@playwright/test';

const textPdf = (text: string) => {
  const stream = `BT /F1 12 Tf 72 720 Td (${text.replace(/[()\\]/g, '\\$&')}) Tj ET`;
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
  ];
  return makePdf(objects);
};

const imageOnlyPdf = () => makePdf([
  '<< /Type /Catalog /Pages 2 0 R >>',
  '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] >>',
]);

const makePdf = (objects: string[]) => {
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets[index + 1] = pdf.length;
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  pdf += offsets.slice(1).map((offset) => `${String(offset).padStart(10, '0')} 00000 n `).join('\n');
  pdf += `\ntrailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return Buffer.from(pdf);
};

async function openWorkspace(page: import('@playwright/test').Page) {
  await page.goto('/');
  await page.getByTestId('button-try-redline').click();
  await page.getByTestId('input-demo-email').fill('demo@fineline.test');
  await page.getByTestId('input-demo-password').fill('fineline-demo');
  await page.getByTestId('button-demo-login').click();
  await expect(page.getByTestId('textarea-contract')).toBeVisible();
}

test.describe('PDF contract uploads', () => {
  test('loads extracted text from a text-based PDF into the contract editor', async ({ page }) => {
    await openWorkspace(page);
    const contractText = 'This agreement has a text-based termination clause.';

    await page.getByTestId('input-contract-upload').setInputFiles({
      name: 'contract.pdf',
      mimeType: 'application/pdf',
      buffer: textPdf(contractText),
    });

    await expect(page.getByTestId('textarea-contract')).toHaveValue(contractText);
    await expect(page.getByRole('alert')).toHaveCount(0);
  });

  test('explains when a PDF has no selectable text', async ({ page }) => {
    await openWorkspace(page);

    await page.getByTestId('input-contract-upload').setInputFiles({
      name: 'scanned-contract.pdf',
      mimeType: 'application/pdf',
      buffer: imageOnlyPdf(),
    });

    await expect(page.getByRole('alert')).toContainText(
      'This PDF appears to be scanned or image-only',
    );
    await expect(page.getByTestId('textarea-contract')).toHaveValue('');
  });

  test('shows recovery guidance for an invalid PDF and clears stale findings', async ({ page }) => {
    await openWorkspace(page);
    await page.getByTestId('button-load-sample').click();
    await page.getByTestId('button-scan-contract').click();
    await expect(page.getByTestId('result-risk-renewal')).toBeVisible();

    await page.getByTestId('input-contract-upload').setInputFiles({
      name: 'broken.pdf',
      mimeType: 'application/pdf',
      buffer: Buffer.from('not a PDF'),
    });

    await expect(page.getByRole('alert')).toContainText(
      'This PDF could not be read in the browser',
    );
    await expect(page.getByTestId('textarea-contract')).toHaveValue('');
    await expect(page.getByTestId('result-risk-renewal')).toHaveCount(0);
  });
});