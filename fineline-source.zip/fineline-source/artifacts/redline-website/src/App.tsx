import { type ChangeEvent, type FormEvent, type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import * as pdfjsLib from 'pdfjs-dist';
import { ArrowDown, ArrowRight, Check, ChevronDown, ChevronRight, CircleAlert, CircleCheck, FileText, Flag, Menu, Minus, MoveUpRight, PenLine, ScanSearch, Shield, Sparkles, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

// FineLine — contract clarity for freelancers.
// Written by Elyse Dequina.

const queryClient = new QueryClient();

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();

type Risk = {
  id: string;
  number: string;
  title: string;
  short: string;
  clause: string;
  why: string;
  ask: string;
  tone: 'critical' | 'watch';
};

// The five core contract risks FineLine surfaces in the demo workspace.
const risks: Risk[] = [
  { id: 'renewal', number: '01', title: 'Auto-renewal clauses', short: 'The quiet extension', clause: 'This Agreement will automatically renew for successive twelve (12) month periods unless either party provides written notice of non-renewal at least 60 days prior to the end of the then-current term.', why: 'Miss the window and you are committed for another year, even if the work has changed or the client has gone quiet.', ask: 'Change the notice period to 14 days, or remove automatic renewal entirely.', tone: 'watch' },
  { id: 'liability', number: '02', title: 'Unlimited liability', short: 'The blank cheque', clause: 'Contractor shall be liable for any and all losses, costs, claims, damages, and expenses arising out of or related to the Services, without limitation.', why: 'A modest project should not expose your personal finances to an open-ended claim. One typo should not become an unlimited bill.', ask: 'Cap your total liability at the fees paid under this agreement.', tone: 'critical' },
  { id: 'ip', number: '03', title: 'IP assignment', short: 'Giving away the toolbox', clause: 'All right, title, and interest in any materials, tools, processes, concepts, and deliverables created by Contractor shall vest exclusively in Client upon creation.', why: 'As written, the client could claim ownership of your reusable templates, methods, and work-in-progress — not just the final deliverable.', ask: 'Carve out pre-existing materials, tools, and general know-how from the assignment.', tone: 'critical' },
  { id: 'noncompete', number: '04', title: 'Non-competes', short: 'The door closing behind you', clause: 'During the term and for twelve (12) months thereafter, Contractor shall not provide services to any business that competes with Client.', why: 'A broad restriction can quietly shrink your client list and stop you taking work in your own industry.', ask: 'Limit the restriction to named, direct competitors — or delete it.', tone: 'watch' },
  { id: 'termination', number: '05', title: 'Unilateral termination rights', short: 'The one-way exit', clause: 'Client may terminate this Agreement at any time, for any reason, upon written notice. Contractor shall be paid only for accepted work completed through the effective date.', why: 'They can leave whenever they want, while your payment depends on a vague idea of what counts as accepted.', ask: 'Add 14 days’ notice and payment for work completed plus committed costs.', tone: 'watch' },
];

const DEMO_EMAIL = 'demo@fineline.test';
const DEMO_PASSWORD = 'fineline-demo';
const SESSION_KEY = 'fineline-demo-session';
const sampleContract = `${risks[0].clause}

${risks[1].clause}

${risks[2].clause}

${risks[3].clause}

${risks[4].clause}`;

type AnalysisMatch = Risk & { matchedClause: string };

// The demo scan stays in the browser and uses transparent keyword matching.
function analyzeContract(text: string): AnalysisMatch[] {
  const sentences = text.split(/(?<=[.!?])\s+|\n+/).map((sentence) => sentence.trim()).filter(Boolean);
  const terms: Record<string, string[]> = {
    renewal: ['renew', 'renewal', 'successive'],
    liability: ['liable', 'liability', 'losses', 'damages', 'without limitation'],
    ip: ['intellectual property', 'work product', 'right, title', 'materials', 'sole property', 'vest exclusively'],
    noncompete: ['non-compete', 'noncompete', 'compete', 'competitor', 'restriction'],
    termination: ['terminate', 'termination', 'effective date', 'without cause', 'without notice'],
  };
  return risks
    .filter((risk) => sentences.some((sentence) => terms[risk.id].some((term) => sentence.toLowerCase().includes(term))))
    .map((risk) => ({
      ...risk,
      matchedClause: sentences.find((sentence) => terms[risk.id].some((term) => sentence.toLowerCase().includes(term))) ?? risk.clause,
    }));
}

async function extractPdfText(file: File): Promise<string> {
  const data = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data }).promise;
  const pages: string[] = [];

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    const pageText = content.items
      .map((item) => ('str' in item ? item.str : ''))
      .filter(Boolean)
      .join(' ')
      .trim();
    if (pageText) pages.push(pageText);
  }

  return pages.join('\n\n');
}

const faqs = [
  { question: 'Is Fineline legal advice?', answer: 'No. Fineline is a plain-language contract safety tool, not a lawyer and not a substitute for legal advice. It helps you spot questions worth asking and gives you practical language for a conversation with a client or counsel.' },
  { question: 'What does Fineline actually check?', answer: 'Every read looks for five recurring pressure points: liability, ownership of work, renewal, restrictions, and exit terms. You get the relevant clause, a plain-English explanation, and a specific next question.' },
  { question: 'Will it rewrite my whole contract?', answer: 'Fineline focuses on the clauses most likely to create an expensive surprise. You get a focused read, not a fog of tracked changes or a document pretending to be your lawyer.' },
  { question: 'What happens to the contracts I upload?', answer: 'Your documents are private to your account and used to generate your report. We do not sell your contracts or use them to train a public model. You can delete a document and its analysis whenever you like.' },
];

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node || typeof IntersectionObserver === 'undefined') { setVisible(true); return; }
    const observer = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } }, { threshold: 0.12 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return { ref, visible };
}

function Reveal({ children, className = '', delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return <div ref={ref} className={`${className} redline-reveal ${visible ? 'is-visible' : ''}`} style={{ transitionDelay: `${delay}ms` }}>{children}</div>;
}

function Logo({ dark = false }: { dark?: boolean }) {
  return <div className={`flex items-center gap-2.5 ${dark ? 'text-[#f3ede4]' : 'text-[#181a19]'}`} aria-label="Fineline home">
    <span className="relative flex h-8 w-8 items-center justify-center border-2 border-current"><span className="absolute h-3.5 w-3.5 bg-[#e33e35]" /><span className="absolute -right-1 -top-1 h-2 w-2 bg-[#181a19]" /></span>
    <span className="redline-mono text-[12px] font-bold uppercase tracking-[.19em]">fineline<span className="text-[#e33e35]">.</span></span>
  </div>;
}

function PaperLines({ widths = ['92%', '84%', '68%'] }: { widths?: string[] }) {
  return <div className="space-y-2">{widths.map((width, index) => <div key={`${width}-${index}`} className="redline-document-line" style={{ width }} />)}</div>;
}

function Agreement() {
  return <div className="redline-document-stage">
    <div className="document-callout document-callout-left document-callout-liability">
      <div className="document-callout-icon"><CircleAlert size={15} /></div>
      <div><div className="redline-mono text-[8px] font-bold uppercase tracking-[.1em] text-[#d9443c]">Unlimited liability</div><p>You could be liable for <strong>any and all losses.</strong></p></div>
    </div>
    <div className="document-callout document-callout-right document-callout-payment">
      <div className="document-callout-icon"><CircleAlert size={15} /></div>
      <div><div className="redline-mono text-[8px] font-bold uppercase tracking-[.1em] text-[#d9443c]">90-day payment terms</div><p>Payment is not due for up to <strong>90 days.</strong></p></div>
    </div>
    <div className="document-callout document-callout-left document-callout-ip">
      <div className="document-callout-icon"><FileText size={15} /></div>
      <div><div className="redline-mono text-[8px] font-bold uppercase tracking-[.1em] text-[#d9443c]">Client owns your work</div><p>All deliverables become the <strong>property of the client.</strong></p></div>
    </div>
    <div className="document-callout document-callout-right document-callout-termination">
      <div className="document-callout-icon"><X size={15} /></div>
      <div><div className="redline-mono text-[8px] font-bold uppercase tracking-[.1em] text-[#d9443c]">Termination without notice</div><p>They can end the agreement <strong>at any time.</strong></p></div>
    </div>
    <div className="relative z-[1] rotate-[1.4deg] border border-[#181a19]/25 bg-[#fcf9f3] p-5 shadow-[14px_16px_0_rgba(24,26,25,.13)] sm:p-8">
      <div className="mb-6 flex items-center justify-between border-b border-[#181a19]/15 pb-4"><div className="flex items-center gap-2"><FileText size={17} className="text-[#d9443c]" /><span className="redline-mono text-[9px] font-bold uppercase tracking-[.14em]">website-redesign_agreement.pdf</span></div><span className="redline-mono text-[9px] text-[#181a19]/45">6 pages</span></div>
      <div className="mb-6 text-center"><div className="redline-mono mb-3 text-[10px] font-bold uppercase tracking-[.18em]">Agreement</div><div className="mx-auto h-[7px] w-[34%] bg-[#918b82]" /></div>
      <div className="space-y-6 text-[10px] leading-[1.5] text-[#3b3b37] sm:text-[11px]">
        <div className="grid grid-cols-[22px_1fr_1fr] gap-2"><span className="redline-mono text-[#77736c]">8.</span><p>Contractor shall be liable for <span className="redline-highlight">any and all losses</span>, costs, claims, damages, and expenses arising out of or related to the Services, <span className="redline-highlight redline-highlight-strong">without limitation.</span></p><PaperLines /></div>
        <div className="grid grid-cols-[22px_1fr_1fr] gap-2"><span className="redline-mono text-[#77736c]">9.</span><PaperLines widths={['95%', '74%', '86%']} /><p>Client shall pay Contractor within <span className="redline-highlight">ninety (90) days</span> of receipt of invoice.</p></div>
        <div className="grid grid-cols-[22px_1fr_1fr] gap-2"><span className="redline-mono text-[#77736c]">11.</span><p>All work product, including drafts and concepts, shall be the <span className="redline-highlight">sole property of the Client.</span></p><PaperLines widths={['86%', '92%', '60%']} /></div>
        <div className="grid grid-cols-[22px_1fr_1fr] gap-2"><span className="redline-mono text-[#77736c]">14.</span><PaperLines widths={['74%', '56%']} /><p>Client may terminate this Agreement <span className="redline-highlight">at any time, with or without cause or notice.</span></p></div>
      </div>
      <div className="mt-8 flex items-end justify-between border-t border-[#181a19]/15 pt-4"><div><div className="redline-mono text-[9px] font-bold uppercase tracking-[.12em] text-[#d9443c]">04 / 05 risks found</div><div className="mt-1 text-[12px] font-bold">Worth a conversation.</div></div><div className="flex h-9 w-9 items-center justify-center border border-[#d9443c] text-[#d9443c]"><ArrowDown size={18} /></div></div>
    </div>
  </div>;
}

function Header({ scrollTo, onOpenAuth }: { scrollTo: (id: string) => void; onOpenAuth: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const go = (id: string) => { setMobileOpen(false); scrollTo(id); };
  return <><div className="border-b border-[#f3ede4]/20 bg-[#181a19] px-5 py-2 text-center text-[9px] font-bold uppercase tracking-[.17em] text-[#f3ede4] sm:text-[10px]">Built for the people who sign the work <span className="mx-2 text-[#e33e35]">/</span> No legal degree required</div>
    <header className="relative z-30 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-5 sm:px-8 lg:px-10">
      <button type="button" data-testid="button-back-to-top" onClick={() => go('top')} aria-label="Back to top"><Logo /></button>
      <nav className="hidden items-center gap-8 text-[11px] font-bold uppercase tracking-[.14em] text-[#181a19]/70 lg:flex">
        {['how-it-works', 'risk-index', 'pricing', 'for-freelancers'].map((id) => <button key={id} type="button" data-testid={`button-nav-${id}`} onClick={() => go(id)} className="transition-colors hover:text-[#e33e35]">{id === 'how-it-works' ? 'How it works' : id === 'risk-index' ? 'What it catches' : id === 'for-freelancers' ? 'For freelancers' : 'Pricing'}</button>)}
      </nav>
      <div className="hidden items-center gap-5 lg:flex"><button type="button" data-testid="button-sign-in" onClick={onOpenAuth} className="text-[11px] font-bold uppercase tracking-[.14em] text-[#181a19]/70 hover:text-[#e33e35]">Sign in</button><button type="button" data-testid="button-try-redline" onClick={onOpenAuth} className="redline-button flex items-center gap-2 bg-[#e33e35] px-4 py-3 text-[11px] font-bold uppercase tracking-[.13em] text-[#fff9f0]">Try Fineline <ArrowRight size={14} /></button></div>
      <button type="button" data-testid="button-toggle-menu" className="p-2 lg:hidden" onClick={() => setMobileOpen((open) => !open)} aria-label="Toggle menu" aria-expanded={mobileOpen}>{mobileOpen ? <X size={22} /> : <Menu size={22} />}</button>
      {mobileOpen && <div className="absolute left-5 right-5 top-[70px] border border-[#181a19] bg-[#f3ede4] p-5 shadow-[7px_7px_0_#e33e35] lg:hidden"><div className="flex flex-col gap-5 text-left text-[11px] font-bold uppercase tracking-[.14em]">{['how-it-works', 'risk-index', 'pricing', 'for-freelancers'].map((id) => <button key={id} type="button" data-testid={`button-mobile-${id}`} onClick={() => go(id)}>{id === 'how-it-works' ? 'How it works' : id === 'risk-index' ? 'What it catches' : id === 'for-freelancers' ? 'For freelancers' : 'Pricing'}</button>)}<button type="button" data-testid="button-mobile-signup" onClick={() => { setMobileOpen(false); onOpenAuth(); }} className="border-t border-[#181a19]/20 pt-5 text-left text-[#e33e35]">Start your read <ArrowRight className="ml-1 inline" size={14} /></button></div></div>}
    </header></>;
}

// This login is intentionally test-only; it does not create real accounts.
function DemoLogin({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    document.addEventListener('keydown', closeOnEscape);
    return () => document.removeEventListener('keydown', closeOnEscape);
  }, [onClose]);
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (email.trim().toLowerCase() !== DEMO_EMAIL || password !== DEMO_PASSWORD) {
      setError('That demo sign-in does not match the preset credentials.');
      return;
    }
    onSuccess();
  };
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#181a19]/75 p-5" role="dialog" aria-modal="true" aria-labelledby="demo-login-title">
    <div className="relative w-full max-w-[480px] border border-[#181a19] bg-[#f3ede4] p-6 shadow-[9px_9px_0_#e33e35] sm:p-8">
      <button type="button" onClick={onClose} aria-label="Close demo sign-in" className="absolute right-5 top-5 p-1 hover:text-[#e33e35]"><X size={20} /></button>
      <div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">Test access only</div>
      <h2 id="demo-login-title" className="redline-serif pr-8 text-[46px] leading-[.85]">Enter the<br /><span className="text-[#e33e35]">demo workspace.</span></h2>
      <p className="mt-5 max-w-[350px] text-[13px] leading-[1.5] text-[#181a19]/65">No real account is created. Use the preset credentials below — never enter a real password or sensitive information.</p>
      <div className="mt-6 border border-[#181a19]/20 bg-[#c9d4c5] p-4 text-[12px]">
        <div className="redline-mono mb-2 text-[8px] font-bold uppercase tracking-[.12em]">Preset demo credentials</div>
        <div><span className="font-bold">Email:</span> {DEMO_EMAIL}</div><div><span className="font-bold">Password:</span> {DEMO_PASSWORD}</div>
      </div>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <div><label htmlFor="demo-email" className="mb-1.5 block text-[12px] font-bold">Demo email</label><input id="demo-email" data-testid="input-demo-email" type="email" autoComplete="off" autoFocus value={email} onChange={(event) => { setEmail(event.target.value); setError(''); }} className="w-full border border-[#181a19]/35 bg-[#fcf9f3] px-3 py-3 text-[14px] outline-none focus:border-[#e33e35]" /></div>
        <div><label htmlFor="demo-password" className="mb-1.5 block text-[12px] font-bold">Demo password</label><input id="demo-password" data-testid="input-demo-password" type="password" autoComplete="off" value={password} onChange={(event) => { setPassword(event.target.value); setError(''); }} className="w-full border border-[#181a19]/35 bg-[#fcf9f3] px-3 py-3 text-[14px] outline-none focus:border-[#e33e35]" /></div>
        {error && <p role="alert" className="text-[12px] font-bold text-[#b52f2c]">{error}</p>}
        <button type="submit" data-testid="button-demo-login" className="redline-button flex w-full items-center justify-center gap-2 bg-[#e33e35] px-5 py-4 text-[11px] font-bold uppercase tracking-[.13em] text-[#fff9f0]">Open demo workspace <ArrowRight size={14} /></button>
      </form>
    </div>
  </div>;
}

// Local contract workspace for testing uploads, PDF extraction, and risk scans.
function ContractWorkspace({ onSignOut }: { onSignOut: () => void }) {
  const [contract, setContract] = useState('');
  const [matches, setMatches] = useState<AnalysisMatch[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [hasAnalyzed, setHasAnalyzed] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const scan = () => {
    if (!contract.trim()) { setMatches(null); setHasAnalyzed(false); return; }
    setLoading(true);
    window.setTimeout(() => { setMatches(analyzeContract(contract)); setHasAnalyzed(true); setLoading(false); }, 450);
  };
  const loadSample = () => { setContract(sampleContract); setMatches(null); setHasAnalyzed(false); };
  const uploadContract = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
    if (!isPdf && !file.type.startsWith('text/') && !/\.(txt|md|rtf)$/i.test(file.name)) {
      setUploadError('For this local demo, upload a .txt, .md, .rtf, or PDF file.');
      return;
    }
    setUploadError('');
    setUploading(isPdf);
    setMatches(null);
    setHasAnalyzed(false);
    if (isPdf) {
      void extractPdfText(file).then((text) => {
        if (!text.trim()) {
          setContract('');
          setUploadError('This PDF appears to be scanned or image-only, so no selectable contract text was found. Try an accessible PDF or paste the text here.');
          return;
        }
        setContract(text);
      }).catch(() => {
        setContract('');
        setUploadError('This PDF could not be read in the browser. Try exporting it again as a text-based PDF, or paste the contract text here.');
      }).finally(() => setUploading(false));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === 'string' ? reader.result : '';
      if (!text.trim()) { setUploadError('That file is empty. Choose a text file with contract language.'); return; }
      setContract(text);
      setUploading(false);
    };
    reader.onerror = () => { setUploadError('That file could not be read. Try saving it as plain text and upload it again.'); setUploading(false); };
    reader.readAsText(file);
  };
  const copy = (risk: Risk) => void navigator.clipboard?.writeText(`Would you be open to ${risk.ask.toLowerCase()}`);
  return <main className="redline-page min-h-[100dvh]">
    <header className="border-b border-[#181a19]/20 bg-[#f3ede4] px-5 py-5 sm:px-8"><div className="mx-auto flex max-w-[1240px] items-center justify-between"><Logo /><div className="flex items-center gap-4"><span className="hidden text-[11px] text-[#181a19]/55 sm:inline">Demo session</span><button type="button" data-testid="button-sign-out" onClick={onSignOut} className="border-b border-[#181a19]/40 pb-1 text-[10px] font-bold uppercase tracking-[.12em] hover:border-[#e33e35] hover:text-[#e33e35]">Sign out</button></div></div></header>
    <section className="mx-auto max-w-[1240px] px-5 py-14 sm:px-8 lg:px-10 lg:py-20">
      <div className="mb-12 flex flex-col justify-between gap-6 border-b border-[#181a19]/20 pb-10 lg:flex-row lg:items-end"><div><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">Demo workspace / Local only</div><h1 className="redline-serif text-[clamp(3.8rem,8vw,7.4rem)] leading-[.8] tracking-[-.05em]">Test the<br /><span className="text-[#e33e35]">sharp edges.</span></h1></div><p className="max-w-[330px] text-[14px] leading-[1.55] text-[#181a19]/65">Paste a contract to scan for five recurring pressure points. Nothing leaves this browser, and this is educational — not legal advice.</p></div>
      <div className="grid gap-10 lg:grid-cols-[.85fr_1.15fr]">
         <div><label htmlFor="contract-text" className="redline-mono mb-3 block text-[9px] font-bold uppercase tracking-[.13em]">01 / Contract text</label><textarea id="contract-text" data-testid="textarea-contract" value={contract} onChange={(event) => { setContract(event.target.value); setHasAnalyzed(false); setUploadError(''); }} placeholder="Paste agreement text here…" className="min-h-[320px] w-full resize-y border border-[#181a19] bg-[#fcf9f3] p-5 text-[14px] leading-[1.6] outline-none placeholder:text-[#181a19]/35 focus:border-[#e33e35]" /><div className="mt-4 flex flex-wrap gap-3"><label htmlFor="contract-upload" data-testid="button-upload-contract" className={`flex items-center gap-2 border border-[#181a19]/50 px-4 py-3 text-[10px] font-bold uppercase tracking-[.11em] ${uploading ? 'cursor-wait opacity-60' : 'cursor-pointer hover:border-[#e33e35] hover:text-[#e33e35]'}`}><FileText size={14} /> {uploading ? 'Reading PDF…' : 'Upload file'}</label><input id="contract-upload" data-testid="input-contract-upload" type="file" accept=".txt,.md,.rtf,.pdf,text/plain,text/markdown,application/rtf,application/pdf" onChange={uploadContract} className="sr-only" /><button type="button" data-testid="button-load-sample" onClick={loadSample} className="border border-[#181a19]/50 px-4 py-3 text-[10px] font-bold uppercase tracking-[.11em] hover:border-[#e33e35] hover:text-[#e33e35]">Load sample contract</button><button type="button" data-testid="button-scan-contract" onClick={scan} disabled={loading || uploading || !contract.trim()} className="redline-button flex items-center gap-2 bg-[#e33e35] px-4 py-3 text-[10px] font-bold uppercase tracking-[.11em] text-[#fff9f0] disabled:cursor-not-allowed disabled:opacity-45">Scan locally <ScanSearch size={14} /></button></div>{uploadError && <p role="alert" className="mt-3 text-[12px] font-bold text-[#b52f2c]">{uploadError}</p>}<p className="mt-3 text-[11px] leading-[1.45] text-[#181a19]/55">Upload a .txt, .md, .rtf, or text-based PDF. Files stay in this browser for the demo.</p></div>
        <div aria-live="polite"><div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[.13em]">02 / Findings</div>{loading ? <div className="border border-[#181a19] bg-[#c9d4c5] p-7"><div className="redline-serif text-[34px]">Reading the fine print…</div><p className="mt-2 text-[13px] text-[#181a19]/65">Checking five risk categories locally.</p></div> : !hasAnalyzed ? <div className="flex min-h-[320px] items-center justify-center border border-dashed border-[#181a19]/35 p-8 text-center"><div><ScanSearch className="mx-auto mb-4 text-[#e33e35]" size={28} /><h2 className="redline-serif text-[34px]">Your clear read<br />starts here.</h2><p className="mx-auto mt-3 max-w-[270px] text-[13px] leading-[1.5] text-[#181a19]/60">Paste text or load the sample, then run the local scan.</p></div></div> : matches?.length === 0 ? <div data-testid="status-no-risks" className="border border-[#181a19] bg-[#c9d4c5] p-7"><CircleCheck className="mb-4 text-[#e33e35]" size={27} /><h2 className="redline-serif text-[38px] leading-none">No flagged risks.</h2><p className="mt-3 text-[13px] leading-[1.5] text-[#181a19]/70">None of the five demo checks matched this text. A clean scan is not a legal opinion.</p></div> : <div className="space-y-4">{matches?.map((risk) => <article key={risk.id} data-testid={`result-risk-${risk.id}`} className="border border-[#181a19] bg-[#f3ede4] p-5 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="redline-mono text-[8px] font-bold uppercase tracking-[.13em] text-[#e33e35]">{risk.number} / {risk.short}</div><h2 className="mt-2 text-[19px] font-bold">{risk.title}</h2></div><span className="border border-[#e33e35]/50 bg-[#f1d9d1] px-2 py-1 text-[8px] font-bold uppercase tracking-[.1em] text-[#b52f2c]">{risk.tone === 'critical' ? 'High attention' : 'Worth a look'}</span></div><div className="mt-5 border-l-2 border-[#e33e35] pl-4"><div className="redline-mono mb-1 text-[8px] uppercase tracking-[.1em] text-[#181a19]/45">Matched clause</div><p className="redline-serif text-[17px] leading-[1.4]">{risk.matchedClause}</p></div><p className="mt-4 text-[13px] leading-[1.5] text-[#181a19]/70">{risk.why}</p><div className="mt-4 flex flex-col gap-3 border-t border-[#181a19]/15 pt-4 sm:flex-row sm:items-center sm:justify-between"><p className="text-[12px] font-bold">Next question: <span className="font-normal">{risk.ask}</span></p><button type="button" onClick={() => copy(risk)} className="self-start border-b border-[#181a19]/40 pb-1 text-[9px] font-bold uppercase tracking-[.1em] hover:border-[#e33e35] hover:text-[#e33e35]">Copy question</button></div></article>)}</div>}</div>
      </div>
    </section>
  </main>;
}

function StatsBand() {
  return <div className="border-y border-[#f3ede4]/20 bg-[#181a19] text-[#f3ede4]"><div className="mx-auto grid max-w-[1240px] grid-cols-2 sm:grid-cols-4">{[['$2,000', 'average project protected'], ['5', 'high-stakes risks surfaced'], ['3 min', 'to your first clear question'], ['$0', 'lawyer-shaped price tag']].map(([value, label], index) => <div key={label} data-testid={`stat-${index}`} className={`border-[#f3ede4]/15 px-4 py-6 sm:px-6 sm:py-8 ${index < 3 ? 'border-r' : ''} ${index > 1 ? 'border-t sm:border-t-0' : ''}`}><div className="redline-serif text-[34px] leading-none text-[#e33e35] sm:text-[42px]">{value}</div><div className="mt-2 max-w-[145px] text-[9px] font-bold uppercase leading-[1.35] tracking-[.13em] text-[#f3ede4]/60">{label}</div></div>)}</div></div>;
}

function RiskIndex({ activeRisk, setActiveRisk }: { activeRisk: string; setActiveRisk: (id: string) => void }) {
  const selected = risks.find((risk) => risk.id === activeRisk) ?? risks[1];
  return <section id="risk-index" className="bg-[#c9d4c5] px-5 py-24 sm:px-8 lg:px-10 lg:py-32"><div className="mx-auto max-w-[1240px]"><Reveal><div className="mb-14 flex flex-col justify-between gap-8 lg:flex-row lg:items-end"><div><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">02 — Risk index</div><h2 className="redline-serif text-[clamp(3.7rem,7.5vw,7.4rem)] leading-[.8] tracking-[-.05em]">The usual<br /><span className="text-[#e33e35]">suspects.</span></h2></div><p className="max-w-[315px] text-[14px] leading-[1.55] text-[#181a19]/65">Not every unusual sentence is a problem. These are the ones that deserve a pause before your signature.</p></div></Reveal>
    <div className="grid gap-10 lg:grid-cols-[.78fr_1.22fr]"><Reveal delay={80}><div className="border-t-2 border-[#181a19]">{risks.map((risk) => <button key={risk.id} type="button" data-testid={`button-risk-${risk.id}`} aria-pressed={activeRisk === risk.id} onClick={() => setActiveRisk(risk.id)} className={`group flex w-full items-center justify-between border-b border-[#181a19]/20 py-5 text-left transition-colors hover:text-[#e33e35] ${activeRisk === risk.id ? 'text-[#e33e35]' : ''}`}><span className="flex items-center gap-5"><span className="redline-mono text-[10px] text-[#181a19]/45">{risk.number}</span><span className="text-[16px] font-bold">{risk.title}</span></span><ChevronRight size={17} className={activeRisk === risk.id ? 'translate-x-1' : ''} /></button>)}</div><div className="mt-8 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[.13em] text-[#181a19]/60"><CircleCheck size={16} className="text-[#e33e35]" /> Five checks. One calmer signature.</div></Reveal>
      <Reveal delay={150}><div className="relative border border-[#181a19] bg-[#f3ede4] p-6 sm:p-9" data-testid="panel-selected-risk"><CircleAlert size={18} className="absolute right-5 top-5 text-[#e33e35]" /><div className="redline-mono mb-5 text-[9px] font-bold uppercase tracking-[.14em] text-[#e33e35]">{selected.number} / {selected.short}</div><h3 className="redline-serif text-[43px] leading-[.88] tracking-[-.03em]">{selected.title}</h3><div className="mt-8 border-l-2 border-[#e33e35] pl-5"><div className="redline-mono mb-2 text-[9px] font-bold uppercase tracking-[.12em] text-[#181a19]/45">What the clause says</div><p className="redline-serif text-[19px] leading-[1.45] text-[#181a19]/75">{selected.clause}</p></div><div className="mt-7 grid gap-5 border-t border-[#181a19]/15 pt-6 sm:grid-cols-2"><div><div className="redline-mono mb-2 text-[9px] font-bold uppercase tracking-[.12em] text-[#181a19]/45">Why it matters</div><p className="text-[13px] leading-[1.5] text-[#181a19]/70">{selected.why}</p></div><div><div className="redline-mono mb-2 text-[9px] font-bold uppercase tracking-[.12em] text-[#181a19]/45">Your next step</div><p className="text-[13px] font-bold leading-[1.5]">{selected.ask}</p></div></div></div></Reveal>
    </div></div></section>;
}

function Preview({ activeRisk, setActiveRisk, onCopy }: { activeRisk: string; setActiveRisk: (id: string) => void; onCopy: () => void }) {
  const selected = risks.find((risk) => risk.id === activeRisk) ?? risks[1];
  return <section id="analysis-preview" className="mx-auto max-w-[1240px] px-5 py-24 sm:px-8 lg:px-10 lg:py-32"><Reveal><div className="mb-12 max-w-[680px]"><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">03 — Inside the read</div><h2 className="redline-serif text-[clamp(3.6rem,6.8vw,6.8rem)] leading-[.82] tracking-[-.05em]">No panic.<br /><span className="text-[#e33e35]">Just specifics.</span></h2><p className="mt-6 max-w-[510px] text-[16px] leading-[1.55] text-[#181a19]/63">A Fineline report answers the question behind the question: “What do I say back?”</p></div></Reveal>
    <Reveal delay={100}><div className="redline-grid border border-[#181a19] p-3 sm:p-5 lg:p-8"><div className="grid border border-[#181a19]/25 bg-[#fcf9f3] lg:grid-cols-[220px_1fr]"><aside className="border-b border-[#181a19]/20 bg-[#e3dbd0] p-5 lg:border-b-0 lg:border-r"><Logo /><div className="redline-mono mb-3 mt-9 text-[9px] font-bold uppercase tracking-[.12em] text-[#181a19]/45">Your read</div><div className="text-[14px] font-bold leading-[1.3]">Brand-partnership<br />agreement</div><div className="mt-5 space-y-1">{risks.map((risk) => <button key={risk.id} type="button" data-testid={`button-preview-risk-${risk.id}`} onClick={() => setActiveRisk(risk.id)} className={`flex w-full items-center gap-2 px-2 py-2 text-left text-[11px] ${activeRisk === risk.id ? 'bg-[#f3ede4] font-bold text-[#e33e35]' : 'text-[#181a19]/60 hover:text-[#e33e35]'}`}><span className={`h-1.5 w-1.5 rounded-full ${risk.tone === 'critical' ? 'bg-[#e33e35]' : 'bg-[#d49538]'}`} />{risk.title}</button>)}</div><div className="mt-9 border-t border-[#181a19]/15 pt-4"><div className="redline-mono text-[8px] uppercase tracking-[.1em] text-[#181a19]/45">Overall read</div><div className="mt-1 text-[16px] font-bold">Worth a conversation</div></div></aside>
      <div className="p-5 sm:p-8 lg:p-10"><div className="mb-8 flex flex-wrap items-center justify-between gap-3 border-b border-[#181a19]/15 pb-5"><div><div className="redline-mono text-[9px] font-bold uppercase tracking-[.13em] text-[#e33e35]">Risk {selected.number} of 05</div><h3 className="mt-2 text-[21px] font-bold">{selected.title}</h3></div><span className="flex items-center gap-2 border border-[#e33e35]/50 bg-[#f1d9d1] px-3 py-2 text-[9px] font-bold uppercase tracking-[.1em] text-[#b52f2c]"><CircleAlert size={13} /> {selected.tone === 'critical' ? 'High attention' : 'Worth a look'}</span></div><div className="grid gap-10 xl:grid-cols-[1fr_240px]"><div><div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[.12em] text-[#181a19]/45">The clause</div><p className="redline-serif text-[20px] leading-[1.65] text-[#343631]">{selected.clause}</p><div className="mt-8 border-t border-[#181a19]/15 pt-6"><div className="redline-mono mb-3 text-[9px] font-bold uppercase tracking-[.12em] text-[#181a19]/45">What this means for you</div><p className="max-w-[600px] text-[14px] leading-[1.6] text-[#181a19]/72">{selected.why}</p></div></div><div className="h-fit border border-[#181a19] bg-[#c9d4c5] p-5"><div className="mb-4 flex items-center gap-2 text-[#e33e35]"><Sparkles size={15} /><span className="redline-mono text-[9px] font-bold uppercase tracking-[.12em]">Try this next</span></div><p className="text-[14px] font-bold leading-[1.5]">“{selected.ask}”</p><button type="button" data-testid="button-copy-question" onClick={onCopy} className="mt-5 flex items-center gap-2 border-b border-[#181a19]/50 pb-1 text-[10px] font-bold uppercase tracking-[.1em] hover:border-[#e33e35] hover:text-[#e33e35]">Copy the question <ArrowRight size={13} /></button></div></div><div className="mt-10 flex flex-col gap-4 border-t border-[#181a19]/15 pt-5 text-[11px] text-[#181a19]/50 sm:flex-row sm:items-center sm:justify-between"><span className="flex items-center gap-2"><Shield size={15} className="text-[#e33e35]" /> Educational, not legal advice.</span><span className="redline-mono">Last checked just now</span></div></div></div></div></Reveal></section>;
}

function AppHome() {
  const [activeRisk, setActiveRisk] = useState('liability');
  const [openFaq, setOpenFaq] = useState(0);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [demoOpen, setDemoOpen] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => { setSignedIn(window.localStorage.getItem(SESSION_KEY) === 'true'); }, []);
  const enterDemo = () => { window.localStorage.setItem(SESSION_KEY, 'true'); setSignedIn(true); setDemoOpen(false); };
  const signOut = () => { window.localStorage.removeItem(SESSION_KEY); setSignedIn(false); };
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const submitEmail = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); if (email.trim()) setSubmitted(true); };
  const copyQuestion = () => { const risk = risks.find((item) => item.id === activeRisk) ?? risks[1]; void navigator.clipboard?.writeText(`Would you be open to ${risk.ask.toLowerCase()}`); };
  if (signedIn) return <ContractWorkspace onSignOut={signOut} />;
  return <main id="top" className="redline-page min-h-[100dvh] overflow-hidden"><Header scrollTo={scrollTo} onOpenAuth={() => setDemoOpen(true)} />
    <section className="redline-hero mx-auto max-w-[1400px] px-5 pb-16 pt-12 text-center sm:px-8 sm:pt-16 lg:px-10 lg:pt-20">
      <Reveal><div className="mb-5 flex items-center justify-center gap-3 text-[9px] font-bold uppercase tracking-[.2em] text-[#d9443c]"><span className="h-px w-8 bg-[#d9443c]" />Contract clarity for the self-employed<span className="h-px w-8 bg-[#d9443c]" /></div></Reveal>
      <Reveal delay={70}><h1 className="redline-serif mx-auto max-w-[1100px] text-[clamp(4rem,10.4vw,9.5rem)] leading-[.78] tracking-[-.06em]">Don’t sign <span className="text-[#d9443c]">blind.</span></h1></Reveal>
      <Reveal delay={140}><p className="mx-auto mt-6 max-w-[560px] text-[16px] leading-[1.5] text-[#181a19]/70 sm:text-[18px]">Know what you’re agreeing to before your signature hits the page.</p></Reveal>
       <Reveal delay={210}><div className="mt-7 flex flex-col items-center justify-center gap-4 sm:flex-row"><button type="button" data-testid="button-read-contract" onClick={() => setDemoOpen(true)} className="redline-button flex items-center gap-3 bg-[#d9443c] px-5 py-4 text-[11px] font-bold uppercase tracking-[.12em] text-[#fff9f0]">Read my contract <MoveUpRight size={15} /></button><button type="button" data-testid="button-see-real-read" onClick={() => scrollTo('analysis-preview')} className="redline-arrow-link flex items-center gap-2 border-b border-[#181a19]/40 pb-1 text-[11px] font-bold uppercase tracking-[.12em]">See a real read <ArrowRight size={14} /></button></div></Reveal>
      <Reveal delay={280} className="mt-12 sm:mt-16"><div className="relative mx-auto max-w-[1080px]"><Agreement /><div className="absolute -bottom-6 right-2 z-10 rotate-[-4deg] border border-[#181a19]/20 bg-[#bdc9b6] px-4 py-3 text-left shadow-[5px_5px_0_rgba(24,26,25,.12)] sm:-right-1"><div className="redline-mono text-[9px] font-bold uppercase tracking-[.1em]">Risk level</div><div className="mt-1 flex items-center gap-2 text-[14px] font-bold"><span className="h-2 w-2 rounded-full bg-[#d9443c]" />Worth a conversation</div></div></div></Reveal>
    </section><StatsBand />
    <section id="how-it-works" className="mx-auto max-w-[1240px] px-5 py-24 sm:px-8 lg:px-10 lg:py-32"><Reveal><div className="grid gap-8 border-b border-[#181a19]/20 pb-12 lg:grid-cols-[.8fr_1.2fr] lg:gap-20"><div><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">01 — The approach</div><h2 className="redline-serif max-w-[550px] text-[clamp(3.4rem,6.5vw,6.6rem)] leading-[.82] tracking-[-.045em]">A second set of eyes. <span className="text-[#e33e35]">A sharper voice.</span></h2></div><p className="max-w-[575px] self-end text-[17px] leading-[1.55] text-[#181a19]/68 sm:text-[19px]">Contracts are written to sound reasonable. That is what makes the costly bits so easy to miss. Fineline pulls them into the light, translates the legalese, and gives you a next move you can actually use.</p></div></Reveal><div className="grid md:grid-cols-3">{[{ n: '01', icon: ScanSearch, title: 'Spot the sharp edges', body: 'Upload a contract and Fineline scans for the five clauses most likely to leave a freelancer exposed.' }, { n: '02', icon: PenLine, title: 'Understand the trade', body: 'See what the clause says in plain English, why it matters for your project, and what a fair version looks like.' }, { n: '03', icon: Flag, title: 'Ask for the fix', body: 'Take the suggested question straight to your client. No bluffing. No legal theater. Just a better starting point.' }].map(({ n, icon: Icon, title, body }, index) => <Reveal key={n} delay={index * 90} className="h-full"><div className={`h-full border-b border-[#181a19]/20 py-8 md:border-b-0 md:py-12 md:pr-10 ${index > 0 ? 'md:border-l md:pl-10' : ''}`}><div className="mb-14 flex items-start justify-between"><span className="redline-mono text-[10px] font-bold text-[#e33e35]">{n}</span><Icon size={22} strokeWidth={1.6} /></div><h3 className="redline-serif text-[32px] leading-none">{title}</h3><p className="mt-4 max-w-[300px] text-[14px] leading-[1.55] text-[#181a19]/62">{body}</p></div></Reveal>)}</div></section>
    <RiskIndex activeRisk={activeRisk} setActiveRisk={setActiveRisk} /><Preview activeRisk={activeRisk} setActiveRisk={setActiveRisk} onCopy={copyQuestion} />
    <section className="bg-[#e33e35] px-5 py-24 text-[#fff9f0] sm:px-8 lg:px-10 lg:py-32"><Reveal><div className="mx-auto grid max-w-[1240px] gap-12 lg:grid-cols-[1.1fr_.9fr] lg:items-end"><div><div className="redline-mono mb-5 text-[9px] font-bold uppercase tracking-[.16em] text-[#181a19]">The point</div><blockquote className="redline-serif max-w-[850px] text-[clamp(3.2rem,6.6vw,7.3rem)] leading-[.86] tracking-[-.045em]">“You can be easy to work with without being easy to take advantage of.”</blockquote><div className="mt-8 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[.13em] text-[#181a19]"><span className="h-px w-7 bg-[#181a19]" />Fineline principle 01</div></div><p className="max-w-[380px] border-t border-[#181a19]/30 pt-6 text-[17px] leading-[1.5] text-[#181a19]/80 lg:border-l lg:border-t-0 lg:pl-10">The best negotiation is not a standoff. It is knowing exactly what you are asking for — before the pressure to “just sign” starts.</p></div></Reveal></section>
     <section id="pricing" className="border-y border-[#181a19]/20 bg-[#e7ded3] px-5 py-24 sm:px-8 lg:px-10 lg:py-28"><div className="mx-auto grid max-w-[1240px] items-end gap-12 lg:grid-cols-2"><Reveal><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">04 — Keep it fair</div><h2 className="redline-serif text-[clamp(3.6rem,7vw,7rem)] leading-[.8] tracking-[-.05em]">A small fee<br />for a <span className="text-[#e33e35]">big pause.</span></h2><p className="mt-7 max-w-[425px] text-[16px] leading-[1.55] text-[#181a19]/65">One clear read costs less than one overlooked clause. Start before the signature, not after the problem.</p></Reveal><Reveal delay={100}><div className="border border-[#181a19] bg-[#f3ede4] p-6 shadow-[7px_7px_0_#c9d4c5] sm:p-8"><div className="flex items-start justify-between border-b border-[#181a19]/15 pb-6"><div><div className="redline-mono text-[9px] font-bold uppercase tracking-[.13em] text-[#e33e35]">The freelancer read</div><h3 className="redline-serif mt-3 text-[39px] leading-none">One contract</h3></div><div className="redline-serif text-[46px] leading-none">$12</div></div><ul className="space-y-3 py-6 text-[13px] text-[#181a19]/75">{['Five high-stakes risk checks', 'Plain-language explanations', 'A specific question for each risk', 'Private, downloadable report'].map((item) => <li key={item} className="flex items-center gap-3"><Check size={15} className="text-[#e33e35]" />{item}</li>)}</ul><button type="button" data-testid="button-start-read-pricing" onClick={() => setDemoOpen(true)} className="redline-button flex w-full items-center justify-center gap-2 bg-[#e33e35] px-5 py-4 text-[11px] font-bold uppercase tracking-[.13em] text-[#fff9f0]">Start a read <MoveUpRight size={14} /></button><p className="mt-4 text-center text-[10px] text-[#181a19]/50">No subscription. No lawyer-shaped price tag.</p></div></Reveal></div></section>
    <section id="for-freelancers" className="mx-auto max-w-[1240px] px-5 py-24 sm:px-8 lg:px-10 lg:py-32"><Reveal><div className="grid gap-10 border-b border-[#181a19]/20 pb-12 lg:grid-cols-[.9fr_1.1fr]"><div><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">For the self-employed</div><h2 className="redline-serif max-w-[520px] text-[clamp(3.4rem,6vw,6.2rem)] leading-[.83] tracking-[-.045em]">You can be<br /><span className="text-[#e33e35]">easy to work with</span><br />without being easy to exploit.</h2></div><p className="max-w-[530px] self-end text-[18px] leading-[1.55] text-[#181a19]/67">For designers, developers, strategists, photographers, writers, producers, and consultants. If your name is on the agreement, Fineline is for you.</p></div></Reveal><div className="mx-auto mt-12 max-w-[780px] divide-y divide-[#181a19]/20 border-y border-[#181a19]/20">{faqs.map((faq, index) => <div key={faq.question}><button type="button" data-testid={`button-faq-${index}`} aria-expanded={openFaq === index} onClick={() => setOpenFaq(openFaq === index ? -1 : index)} className="flex w-full items-center justify-between py-5 text-left"><span className="text-[15px] font-bold">{faq.question}</span><span className={`flex h-7 w-7 shrink-0 items-center justify-center border border-[#181a19]/30 ${openFaq === index ? 'bg-[#e33e35] text-[#fff9f0]' : ''}`}>{openFaq === index ? <Minus size={15} /> : <ChevronDown size={15} />}</span></button><div className={`redline-faq-answer ${openFaq === index ? 'open' : ''}`}><div><p className="max-w-[660px] pb-5 pr-8 text-[14px] leading-[1.55] text-[#181a19]/65" data-testid={`text-faq-answer-${index}`}>{faq.answer}</p></div></div></div>)}</div></section>
    <section id="signup" className="bg-[#181a19] px-5 py-24 text-[#f3ede4] sm:px-8 lg:px-10 lg:py-32"><div className="mx-auto grid max-w-[1240px] gap-12 lg:grid-cols-[1fr_.85fr] lg:items-end"><Reveal><div className="redline-mono mb-4 text-[9px] font-bold uppercase tracking-[.16em] text-[#e33e35]">05 — Before you sign</div><h2 className="redline-serif max-w-[720px] text-[clamp(4rem,8vw,8rem)] leading-[.78] tracking-[-.055em]">Make the<br /><span className="text-[#e33e35]">next move.</span></h2><p className="mt-8 max-w-[470px] text-[16px] leading-[1.55] text-[#f3ede4]/65">Bring the contract. Leave with a clearer read and a fair question to send back.</p></Reveal><Reveal delay={100}>{submitted ? <div className="border border-[#c9d4c5]/50 bg-[#c9d4c5] p-6 text-[#181a19] sm:p-8" data-testid="status-email-submitted"><CircleCheck className="mb-5 text-[#e33e35]" size={27} /><h3 className="redline-serif text-[36px] leading-none">You’re on the list.</h3><p className="mt-3 max-w-[330px] text-[14px] leading-[1.5] text-[#181a19]/70">We’ll send the door over when Fineline is ready for your next agreement.</p></div> : <form onSubmit={submitEmail} className="border border-[#f3ede4]/35 p-5 sm:p-7"><div className="redline-mono mb-5 text-[9px] font-bold uppercase tracking-[.13em] text-[#f3ede4]/55">Get first read access</div><label htmlFor="redline-email" className="mb-2 block text-[13px] text-[#f3ede4]/75">Your email</label><div className="flex flex-col gap-3 sm:flex-row"><input id="redline-email" data-testid="input-email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@studio.com" className="min-w-0 flex-1 border border-[#f3ede4]/35 bg-transparent px-4 py-3 text-[14px] text-[#f3ede4] outline-none placeholder:text-[#f3ede4]/35 focus:border-[#e33e35]" /><button type="submit" data-testid="button-submit-email" className="redline-button flex items-center justify-center gap-2 bg-[#e33e35] px-5 py-3 text-[11px] font-bold uppercase tracking-[.12em] text-[#fff9f0]">Get access <ArrowRight size={14} /></button></div><p className="mt-4 text-[10px] leading-[1.45] text-[#f3ede4]/40">No sales sequence. Just a note when your next contract deserves a second look.</p></form>}</Reveal></div></section>
     <footer className="bg-[#181a19] px-5 pb-8 text-[#f3ede4] sm:px-8 lg:px-10"><div className="mx-auto flex max-w-[1240px] flex-col gap-5 border-t border-[#f3ede4]/15 pt-6 sm:flex-row sm:items-center sm:justify-between"><button type="button" data-testid="button-footer-top" onClick={() => scrollTo('top')}><Logo dark /></button><div className="redline-mono text-[9px] uppercase tracking-[.12em] text-[#f3ede4]/40">Plain language for people doing the work.</div><div className="text-[10px] text-[#f3ede4]/40">© 2026 Fineline</div></div></footer>
     {demoOpen && <DemoLogin onClose={() => setDemoOpen(false)} onSuccess={enterDemo} />}
   </main>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={AppHome} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  useEffect(() => {
    document.title = 'FineLine — Don’t sign blind.';
    const description = 'FineLine helps independent freelancers understand a contract before signing, with plain-language risk checks and practical questions to ask.';
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) { meta = document.createElement('meta'); meta.setAttribute('name', 'description'); document.head.appendChild(meta); }
    meta.setAttribute('content', description);
  }, []);
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;