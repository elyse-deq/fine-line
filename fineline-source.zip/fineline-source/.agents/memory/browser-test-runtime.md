---
name: Browser test runtime
description: Environment requirements for running browser-level tests in this workspace
---

Browser-level tests for Vite artifacts should define PORT and BASE_PATH in the test server configuration. Chromium also needs its native Nix libraries declared in `.replit`; otherwise tests can pass in one shell but fail after a workflow restart.

**Why:** The managed Vite config rejects missing environment variables, and browser binaries do not inherit temporary system-library setup across workflow restarts.

**How to apply:** Keep test-server environment explicit and treat browser runtime libraries as reproducible project configuration, not a one-off shell setup.